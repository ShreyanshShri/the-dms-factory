import {
	r as l,
	j as e,
	u as X,
	m as Y,
	a as z,
	R as ee,
	b as B,
	S as ge,
	L as ae,
	T as te,
	C as se,
	d as ue,
	e as pe,
	f as fe,
	v as H,
	g as xe,
} from "./assets/vendor-BJT0b45B.js";
import {
	c as x,
	A as L,
	l as he,
	g as Z,
	D as ve,
} from "./assets/workflow-DPkTZJd0.js";
(function () {
	const s = document.createElement("link").relList;
	if (s && s.supports && s.supports("modulepreload")) return;
	for (const c of document.querySelectorAll('link[rel="modulepreload"]')) p(c);
	new MutationObserver((c) => {
		for (const m of c)
			if (m.type === "childList")
				for (const g of m.addedNodes)
					g.tagName === "LINK" && g.rel === "modulepreload" && p(g);
	}).observe(document, {
		childList: !0,
		subtree: !0,
	});

	function t(c) {
		const m = {};
		return (
			c.integrity && (m.integrity = c.integrity),
			c.referrerPolicy && (m.referrerPolicy = c.referrerPolicy),
			c.crossOrigin === "use-credentials"
				? (m.credentials = "include")
				: c.crossOrigin === "anonymous"
				? (m.credentials = "omit")
				: (m.credentials = "same-origin"),
			m
		);
	}

	function p(c) {
		if (c.ep) return;
		c.ep = !0;
		const m = t(c);
		fetch(c.href, m);
	}
})();
const ie = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x(
			"border bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm",
			a
		),
		...s,
	})
);
ie.displayName = "Card";
const ne = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x("flex flex-col space-y-1.5 p-6", a),
		...s,
	})
);
ne.displayName = "CardHeader";
const re = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x("text-2xl font-bold text-gray-900 dark:text-white", a),
		...s,
	})
);
re.displayName = "CardTitle";
const be = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x("text-sm text-gray-600 dark:text-gray-400", a),
		...s,
	})
);
be.displayName = "CardDescription";
const oe = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x("p-6 pt-0", a),
		...s,
	})
);
oe.displayName = "CardContent";
const ce = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x("flex items-center p-6 pt-0", a),
		...s,
	})
);
ce.displayName = "CardFooter";

function ye({
	children: a,
	className: s,
	gradientSize: t = 200,
	gradientColor: p = "#262626",
	gradientOpacity: c = 0.8,
	gradientFrom: m = "#9E7AFF",
	gradientTo: g = "#FE8BBB",
}) {
	const w = l.useRef(null),
		i = X(-t),
		v = X(-t),
		b = l.useCallback(
			(A) => {
				if (w.current) {
					const { left: D, top: R } = w.current.getBoundingClientRect(),
						$ = A.clientX,
						k = A.clientY;
					i.set($ - D), v.set(k - R);
				}
			},
			[i, v]
		),
		j = l.useCallback(
			(A) => {
				A.relatedTarget ||
					(document.removeEventListener("mousemove", b), i.set(-t), v.set(-t));
			},
			[b, i, t, v]
		),
		T = l.useCallback(() => {
			document.addEventListener("mousemove", b), i.set(-t), v.set(-t);
		}, [b, i, t, v]);
	return (
		l.useEffect(
			() => (
				document.addEventListener("mousemove", b),
				document.addEventListener("mouseout", j),
				document.addEventListener("mouseenter", T),
				() => {
					document.removeEventListener("mousemove", b),
						document.removeEventListener("mouseout", j),
						document.removeEventListener("mouseenter", T);
				}
			),
			[T, b, j]
		),
		l.useEffect(() => {
			i.set(-t), v.set(-t);
		}, [t, i, v]),
		e.jsxs("div", {
			ref: w,
			className: x("group relative flex size-full", s),
			children: [
				e.jsx("div", {
					className: "absolute inset-px z-10 bg-white dark:bg-gray-950",
				}),
				e.jsx("div", {
					className: "relative z-30",
					children: a,
				}),
				e.jsx(Y.div, {
					className:
						"pointer-events-none absolute inset-px z-10 opacity-0 transition-opacity duration-300 group-hover:opacity-100",
					style: {
						background: z`
            radial-gradient(${t}px circle at ${i}px ${v}px, ${p}, transparent 100%)
          `,
						opacity: c,
					},
				}),
				e.jsx(Y.div, {
					className:
						"pointer-events-none absolute inset-0 bg-gray-200 duration-300 group-hover:opacity-100 dark:bg-gray-800",
					style: {
						background: z`
            radial-gradient(${t}px circle at ${i}px ${v}px,
              ${m}, 
              ${g}, 
              hsl(var(--border)) 100%
            )
          `,
					},
				}),
			],
		})
	);
}
// done till here
const we = B(
		"text-sm font-medium leading-none text-gray-900 dark:text-white peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
	),
	S = l.forwardRef(({ className: a, ...s }, t) =>
		e.jsx(ee, {
			ref: t,
			className: x(we(), a),
			...s,
		})
	);
S.displayName = ee.displayName;
const le = l.forwardRef(({ className: a, type: s, ...t }, p) =>
	e.jsx("input", {
		type: s,
		className: x(
			"flex h-10 w-full rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-base text-gray-900 dark:text-white ring-offset-white dark:ring-offset-gray-950 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-gray-900 dark:file:text-white placeholder:text-gray-500 dark:placeholder:text-gray-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 dark:focus-visible:ring-primary-400 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
			a
		),
		ref: p,
		...t,
	})
);
le.displayName = "Input";
const Ne = B(
		"relative w-full rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-gray-600 [&>svg]:dark:text-gray-400",
		{
			variants: {
				variant: {
					default:
						"bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-gray-200 dark:border-gray-700",
					destructive:
						"border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950 text-red-800 dark:text-red-200 [&>svg]:text-red-600 [&>svg]:dark:text-red-400",
				},
			},
			defaultVariants: {
				variant: "default",
			},
		}
	),
	E = l.forwardRef(({ className: a, variant: s, ...t }, p) =>
		e.jsx("div", {
			ref: p,
			role: "alert",
			className: x(
				Ne({
					variant: s,
				}),
				a
			),
			...t,
		})
	);
E.displayName = "Alert";
const Ce = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("h5", {
		ref: t,
		className: x(
			"mb-1 font-semibold leading-none tracking-tight text-gray-900 dark:text-white",
			a
		),
		...s,
	})
);
Ce.displayName = "AlertTitle";
const P = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx("div", {
		ref: t,
		className: x(
			"text-sm text-gray-600 dark:text-gray-400 [&_p]:leading-relaxed",
			a
		),
		...s,
	})
);
P.displayName = "AlertDescription";
const je = B(
		"inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-white dark:ring-offset-gray-950 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 dark:focus-visible:ring-primary-400 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
		{
			variants: {
				variant: {
					default:
						"bg-primary-600 text-white hover:bg-primary-700 dark:bg-primary-600 dark:hover:bg-primary-500",
					destructive:
						"bg-red-600 text-white hover:bg-red-700 dark:bg-red-600 dark:hover:bg-red-500",
					outline:
						"border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-700",
					secondary:
						"bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-600",
					ghost:
						"text-gray-900 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-800",
					link: "text-primary-600 dark:text-primary-400 underline-offset-4 hover:underline hover:text-primary-700 dark:hover:text-primary-300",
				},
				size: {
					default: "h-10 px-4 py-2",
					sm: "h-9 rounded-md px-3",
					lg: "h-11 rounded-md px-8",
					icon: "h-10 w-10",
				},
			},
			defaultVariants: {
				variant: "default",
				size: "default",
			},
		}
	),
	F = l.forwardRef(
		({ className: a, variant: s, size: t, asChild: p = !1, ...c }, m) => {
			const g = p ? ge : "button";
			return e.jsx(g, {
				className: x(
					je({
						variant: s,
						size: t,
						className: a,
					})
				),
				ref: m,
				...c,
			});
		}
	);
F.displayName = "Button";
const Te = ({ log: a }) =>
		e.jsxs("div", {
			className: `log ${a.type}`,
			children: [
				e.jsx("div", {
					className: "log-header",
					children: e.jsx("span", {
						children: a.timestamp,
					}),
				}),
				e.jsx("div", {
					className: "log-body",
					children: a.message,
				}),
			],
		}),
	Ae = ue,
	de = l.forwardRef(({ className: a, ...s }, t) =>
		e.jsx(ae, {
			ref: t,
			className: x(
				"inline-flex h-10 items-center justify-center rounded-md bg-gray-50 dark:bg-gray-700 p-1 text-gray-600 dark:text-gray-400",
				a
			),
			...s,
		})
	);
de.displayName = ae.displayName;
// done till here

const W = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx(te, {
		ref: t,
		className: x(
			"inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-white dark:ring-offset-gray-950 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 dark:focus-visible:ring-primary-400 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-white dark:data-[state=active]:bg-gray-800 data-[state=active]:text-gray-900 dark:data-[state=active]:text-white data-[state=active]:shadow-sm",
			a
		),
		...s,
	})
);
W.displayName = te.displayName;
const _ = l.forwardRef(({ className: a, ...s }, t) =>
	e.jsx(se, {
		ref: t,
		className: x(
			"mt-2 ring-offset-white dark:ring-offset-gray-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-600 dark:focus-visible:ring-primary-400 focus-visible:ring-offset-2",
			a
		),
		...s,
	})
);
_.displayName = se.displayName;
const Ie = "v1.0.0",
	Ee = 15e3,
	q = 1e3,
	C = 2,
	G = 3e3,
	O = (a) => new Promise((s) => setTimeout(s, a)),
	Pe = (a) =>
		a ? `${a.replace(/\s+/g, "_").toLowerCase()}_${H().split("-")[0]}` : H(),
	Se = (a) =>
		({
			ready: e.jsx("span", {
				className: "text-blue-600 dark:text-blue-400",
				children: "Ready",
			}),
			active: e.jsx("span", {
				className: "font-semibold text-success-600 dark:text-success-400",
				children: "Active",
			}),
			completed: e.jsx("span", {
				className: "font-semibold text-blue-600 dark:text-blue-400",
				children: "Completed",
			}),
			paused: e.jsx("span", {
				className: "font-semibold text-warning-600 dark:text-warning-400",
				children: "Paused",
			}),
			failed: e.jsx("span", {
				className: "font-semibold text-red-600 dark:text-red-400",
				children: "Failed",
			}),
		}[a] ||
		e.jsx("span", {
			className: "font-semibold text-gray-500 dark:text-gray-400",
			children: "Campaign status unknown",
		})),
	J = ({ size: a = 4 }) =>
		e.jsxs("svg", {
			"aria-hidden": "true",
			className: `h-${a} w-${a} animate-spin fill-gray-600 dark:fill-gray-400 text-gray-200 dark:text-gray-600`,
			viewBox: "0 0 100 101",
			fill: "none",
			xmlns: "http://www.w3.org/2000/svg",
			children: [
				e.jsx("path", {
					d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
					fill: "currentColor",
				}),
				e.jsx("path", {
					d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
					fill: "currentFill",
				}),
			],
		}),
	K = ({ visible: a, icon: s, color: t }) =>
		a
			? e.jsx("div", {
					className:
						"fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm",
					children: e.jsx("div", {
						className:
							"animate-fade-in flex flex-col items-center justify-center",
						children: e.jsx(s, {
							className: `h-20 w-20 ${t}`,
							strokeWidth: 1.5,
						}),
					}),
			  })
			: null,
	$e = ({
		campaigns: a,
		selectedCampaign: s,
		onCampaignChange: t,
		disabled: p,
		platform: c,
		platformName: m,
	}) =>
		a.length === 0
			? e.jsx(E, {
					children: e.jsxs(P, {
						children: [
							"No ",
							m,
							" campaigns available. Please create one at",
							" ",
							e.jsx("a", {
								href: "https://thebuildfluence.com",
								target: "_blank",
								className:
									"text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300",
								children: "thebuildfluence.com",
							}),
						],
					}),
			  })
			: e.jsxs("select", {
					value: s,
					onChange: (g) => t(g.target.value),
					disabled: p,
					className: `w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-600 dark:focus:ring-primary-400 ${
						p ? "opacity-60 cursor-not-allowed" : ""
					}`,
					children: [
						e.jsxs("option", {
							value: "",
							disabled: !0,
							children: ["Select Your ", m, " Campaign"],
						}),
						a.map((g, w) =>
							e.jsxs(
								"option",
								{
									value: g.id,
									className: "py-2",
									children: [g.name, ": ", Se(g.status)],
								},
								w
							)
						),
					],
			  }),
	Q = ({
		platform: a,
		platformName: s,
		displayName: t,
		onDisplayNameChange: p,
		campaigns: c,
		selectedCampaign: m,
		onCampaignChange: g,
		disabled: w,
	}) =>
		e.jsxs(e.Fragment, {
			children: [
				e.jsxs(S, {
					className:
						"block text-sm font-medium text-gray-900 dark:text-white mb-2",
					children: [s, " Account Name"],
				}),
				e.jsx(le, {
					value: t,
					disabled: w,
					onChange: (i) => p(i.target.value),
					type: "text",
					className: "shadow-sm text-[15px] rounded-md",
					placeholder: `Ex: ${s} account username`,
				}),
				e.jsxs(S, {
					className:
						"block text-sm font-medium text-gray-900 dark:text-white mt-4 mb-2",
					children: ["Choose a ", s, " Campaign"],
				}),
				e.jsx("div", {
					className: "relative w-full",
					children: e.jsx($e, {
						campaigns: c,
						selectedCampaign: m,
						onCampaignChange: g,
						disabled: w,
						platform: a,
						platformName: s,
					}),
				}),
			],
		}),
	// done till here
	ke = () => {
		const [a, s] = l.useState({
				isLoading: !0,
				isLoggedIn: !1,
				isStarting: !1,
				isPausing: !1,
				isAccountActive: !1,
				campaignSelectingDisabled: !1,
				activeTab: "instagram",
				selectedCampaign: "",
				error: null,
				statusMessage: "",
				showSuccessOverlay: !1,
				showPauseOverlay: !1,
			}),
			[t, p] = l.useState({
				instagram: {
					displayName: "",
					widgetId: "",
					campaigns: [],
				},
				twitter: {
					displayName: "",
					widgetId: "",
					campaigns: [],
				},
			}),
			[c, m] = l.useState([]),
			g = t[a.activeTab],
			w = g.campaigns,
			i = (o) => {
				s((r) => ({
					...r,
					...o,
				}));
			},
			v = (o, r) => {
				p((u) => ({
					...u,
					[o]: {
						...u[o],
						...r,
					},
				}));
			},
			b = async (o, r = {}) => {
				const u = new AbortController(),
					d = setTimeout(() => u.abort(), Ee);
				try {
					const n = await fetch(o, {
						...r,
						signal: u.signal,
						credentials: "include",
						headers: {
							"Content-Type": "application/json",
							...r.headers,
						},
					});
					if ((clearTimeout(d), !n.ok))
						throw new Error(`Request failed with status code ${n.status}`);
					return await n.json();
				} catch (n) {
					throw (clearTimeout(d), n);
				}
			},
			j = async () => {
				var o, r, u, d, n;
				i({
					isLoading: !0,
					error: null,
					isAccountActive: !1,
				});
				try {
					const f = await b(`${L}/`);
					if (!(f != null && f.campaigns) || !Array.isArray(f.campaigns)) {
						p({
							instagram: {
								displayName: "",
								widgetId: "",
								campaigns: [],
							},
							twitter: {
								displayName: "",
								widgetId: "",
								campaigns: [],
							},
						}),
							chrome.storage.local.remove([
								"instagramDisplayName",
								"twitterDisplayName",
								"instagramWidgetId",
								"twitterWidgetId",
							]),
							he("error", "get all campaigns", "No campaigns found"),
							i({
								error: "No campaigns found. Please create a campaign first.",
								isLoading: !1,
							});
						return;
					}
					const h = f.campaigns,
						I = h.filter((y) => y.platform === "instagram"),
						N = h.filter((y) => y.platform === "twitter");
					p((y) => ({
						instagram: {
							...y.instagram,
							campaigns: I,
						},
						twitter: {
							...y.twitter,
							campaigns: N,
						},
					})),
						chrome.storage.local.get(
							[
								"instagramDisplayName",
								"twitterDisplayName",
								"instagramWidgetId",
								"twitterWidgetId",
							],
							async (y) => {
								p((V) => ({
									instagram: {
										...V.instagram,
										displayName: y.instagramDisplayName || "",
										widgetId: y.instagramWidgetId || "",
									},
									twitter: {
										...V.twitter,
										displayName: y.twitterDisplayName || "",
										widgetId: y.twitterWidgetId || "",
									},
								}));
								const M = a.activeTab === "instagram" ? I : N;
								M.length > 0 &&
									i({
										selectedCampaign: M[0].id,
									});
								const U = y[`${a.activeTab}WidgetId`];
								U && M.length > 0 && (await T(U, M));
							}
						);
					const me = await Z();
					m(me.reverse()),
						i({
							isLoggedIn: !0,
						});
				} catch (f) {
					console.error("Error initializing popup:", f),
						p({
							instagram: {
								displayName: "",
								widgetId: "",
								campaigns: [],
							},
							twitter: {
								displayName: "",
								widgetId: "",
								campaigns: [],
							},
						});
					let h =
						"Failed to load campaigns. Please check your connection and try again.";
					(o = f.message) != null && o.includes("401")
						? (h =
								"Please login to load campaigns. Visit thebuildfluence.com to sign in.")
						: ((r = f.message) != null && r.includes("404")) ||
						  ((u = f.message) != null && u.includes("500"))
						? (h =
								"Server temporarily unavailable. Please try again in a moment.")
						: (d = f.message) != null && d.includes("timeout")
						? (h =
								"Connection timed out. Please check your internet and try again.")
						: (n = f.message) != null &&
						  n.includes("Network Error") &&
						  (h = "Network error. Please check your internet connection."),
						i({
							error: h,
						});
				} finally {
					i({
						isLoading: !1,
					});
				}
			},
			T = async (o, r) => {
				var u, d;
				try {
					const n = await b(`${L}/account-status?widgetID=${o}`);
					if ((n == null ? void 0 : n.success) === !0) {
						const f = (u = n.account) == null ? void 0 : u.status,
							h = (d = n.account) == null ? void 0 : d.campaignId;
						f === "active" &&
							h &&
							r.some((N) => N.id === h) &&
							i({
								selectedCampaign: h,
								campaignSelectingDisabled: !0,
								isAccountActive: !0,
							});
					}
				} catch (n) {
					console.warn(
						"Error checking account status:",
						n == null ? void 0 : n.message
					);
				}
			},
			A = async (o) => {
				i({
					activeTab: o,
				});
				const r = t[o].campaigns;
				if (r.length === 0) {
					i({
						selectedCampaign: "",
						campaignSelectingDisabled: !1,
						isAccountActive: !1,
					});
					return;
				}
				chrome.storage.local.get([`${o}WidgetId`], async (u) => {
					const d = u[`${o}WidgetId`];
					if (!d) {
						i({
							selectedCampaign: r[0].id,
							campaignSelectingDisabled: !1,
							isAccountActive: !1,
						});
						return;
					}
					await T(d, r);
				});
			},
			D = async () => {
				if (!a.selectedCampaign) {
					i({
						statusMessage: "Please select a campaign.",
					});
					return;
				}
				if (!g.displayName) {
					i({
						statusMessage: `Please enter a ${a.activeTab} display name.`,
					});
					return;
				}
				if (!w.some((n) => n.id === a.selectedCampaign)) {
					i({
						statusMessage:
							"Error: Campaign not found. Please refresh and try again.",
					});
					return;
				}
				i({
					isStarting: !0,
					statusMessage: "Starting campaign...",
				});
				const r = g.widgetId || Pe(g.displayName);
				v(a.activeTab, {
					widgetId: r,
				}),
					await new Promise((n) => {
						const f = {
							[`${a.activeTab}DisplayName`]: g.displayName,
							[`${a.activeTab}WidgetId`]: r,
						};
						chrome.storage.local.set(f, n);
					});
				let u = 0,
					d = !1;
				for (; u <= C && !d; )
					try {
						const n = await b(`${L}/start?campaignID=${a.selectedCampaign}`, {
							method: "POST",
							body: JSON.stringify({
								displayName: g.displayName,
								widgetId: r,
							}),
						});
						if (n.success) {
							(d = !0),
								i({
									campaignSelectingDisabled: !0,
								}),
								await new Promise((h, I) => {
									chrome.runtime.sendMessage(
										{
											action: ve,
											platform: a.activeTab,
											widgetId: r,
										},
										(N) => {
											chrome.runtime.lastError
												? I(new Error(chrome.runtime.lastError.message))
												: N != null && N.success
												? h()
												: I(new Error("Failed to start campaign"));
										}
									);
								}),
								i({
									statusMessage: "Campaign Started Successfully!",
									isAccountActive: !0,
									showSuccessOverlay: !0,
								}),
								setTimeout(() => {
									i({
										showSuccessOverlay: !1,
									});
								}, G),
								await O(3500);
							const f = await Z();
							m(f.reverse()), await j();
						} else
							i({
								statusMessage: `Failed to start campaign: ${
									n.message || "Unknown error"
								}`,
							});
					} catch (n) {
						u++,
							u <= C
								? (i({
										statusMessage: `Connection issue, retrying... (${u}/${C})`,
								  }),
								  await O(q))
								: i({
										statusMessage: `Error starting campaign: ${
											(n == null ? void 0 : n.message) || "Unknown error"
										}`,
										campaignSelectingDisabled: !1,
								  });
					} finally {
						(d || u > C) &&
							i({
								isStarting: !1,
							});
					}
			},
			R = async () => {
				if (!a.selectedCampaign) {
					i({
						statusMessage: "Please select a campaign.",
					});
					return;
				}
				const o = g.widgetId;
				if (!o) {
					i({
						statusMessage: `Widget ID not found. Please start ${a.activeTab} campaign first.`,
						isPausing: !1,
					});
					return;
				}
				i({
					isPausing: !0,
					statusMessage: "",
				});
				let r = 0,
					u = !1;
				for (; r <= C && !u; )
					try {
						const d = await b(
							`${L}/pause?campaignID=${a.selectedCampaign}&accountId=${o}`,
							{
								method: "PATCH",
							}
						);
						d != null && d.success
							? ((u = !0),
							  i({
									statusMessage: "Campaign Paused!",
									campaignSelectingDisabled: !1,
									isAccountActive: !1,
									showPauseOverlay: !0,
							  }),
							  setTimeout(() => {
									i({
										showPauseOverlay: !1,
									});
							  }, G),
							  await j())
							: i({
									statusMessage: `Failed to pause campaign: ${
										d.message || "Unknown error"
									}`,
							  });
					} catch (d) {
						r++,
							r <= C
								? (i({
										statusMessage: `Connection issue, retrying... (${r}/${C})`,
								  }),
								  await O(q))
								: i({
										statusMessage: `Error pausing campaign: ${
											(d == null ? void 0 : d.message) || "Unknown error"
										}`,
								  });
					} finally {
						(u || r > C) &&
							i({
								isPausing: !1,
							});
					}
			},
			$ = (o) => {
				i({
					selectedCampaign: o,
				}),
					a.isAccountActive
						? i({
								statusMessage:
									"Stop the current campaign before changing to a new one",
						  })
						: chrome.storage.local.set({
								[`${a.activeTab}CampaignId`]: o,
						  });
			},
			k = (o) => {
				v(a.activeTab, {
					displayName: o,
				});
			};
		return (
			l.useEffect(() => {
				j();
			}, []),
			e.jsxs(e.Fragment, {
				children: [
					e.jsx(K, {
						visible: a.showSuccessOverlay,
						icon: pe,
						color: "text-success-500 dark:text-success-400",
					}),
					e.jsx(K, {
						visible: a.showPauseOverlay,
						icon: fe,
						color: "text-warning-500 dark:text-warning-400",
					}),
					e.jsx(ye, {
						className: "w-full max-w-[500px] custom-scrollbar",
						gradientColor: "#3b83f68c",
						gradientSize: 25,
						gradientOpacity: 0.2,
						gradientFrom: "#3B82F6",
						gradientTo: "#3B82F6",
						children: e.jsxs(ie, {
							className: "bg-transparent border-none z-0 w-[450px]",
							children: [
								e.jsxs(ne, {
									className: "border-b border-gray-200 dark:border-gray-700",
									children: [
										e.jsxs("div", {
											className: "flex",
											children: [
												e.jsxs(re, {
													className:
														"text-2xl font-bold text-gray-900 dark:text-white mr-auto",
													children: [
														"The ",
														e.jsx("span", {
															// className: "underline",
															children: "Buildfluence",
														}),
													],
												}),
												e.jsx("p", {
													className:
														"text-xs text-gray-500 dark:text-gray-400 ml-auto my-auto",
													children: Ie,
												}),
											],
										}),
										e.jsxs("p", {
											className: "text-sm text-gray-600 dark:text-gray-400",
											children: [
												"Before starting a campaign, login to ",
												a.activeTab === "instagram"
													? "Instagram"
													: "X (Twitter)",
												" with the account you want to use for sending DMs.",
											],
										}),
										e.jsx("p", {
											className:
												"text-xs text-warning-600 dark:text-warning-400",
											children: "Browser Language must be in English",
										}),
									],
								}),
								e.jsx(oe, {
									className: "px-2 space-y-8 mt-6 mb-2",
									children: e.jsx("div", {
										className: "w-full flex flex-col px-4",
										children: a.isLoading
											? e.jsxs("div", {
													className: "flex flex-col m-auto",
													children: [
														e.jsx("div", {
															className: "m-auto",
															children: e.jsx(J, {
																size: 10,
															}),
														}),
														e.jsx(S, {
															className:
																"block text-md font-medium text-gray-900 dark:text-white mt-4 mb-4 text-center",
															children: "Loading Data...",
														}),
													],
											  })
											: e.jsxs(e.Fragment, {
													children: [
														!a.isLoggedIn &&
															e.jsx(E, {
																children: e.jsxs(P, {
																	children: [
																		"Please login or create your account at:",
																		" ",
																		e.jsx("a", {
																			href: "https://thebuildfluence.com/register",
																			target: "_blank",
																			className:
																				"text-primary-600 hover:text-primary-700 dark:text-primary-400 dark:hover:text-primary-300",
																			children: "thebuildfluence.com",
																		}),
																	],
																}),
															}),
														a.error &&
															e.jsx(E, {
																variant: "destructive",
																children: e.jsx(P, {
																	children: a.error,
																}),
															}),
														!a.isLoading &&
															!a.error &&
															e.jsxs(Ae, {
																value: a.activeTab,
																onValueChange: A,
																className: "w-[400px]",
																children: [
																	e.jsxs(de, {
																		className: "grid w-full grid-cols-2",
																		children: [
																			e.jsx(W, {
																				value: "instagram",
																				children: "Instagram",
																			}),
																			e.jsx(W, {
																				value: "twitter",
																				children: "X (Twitter)",
																			}),
																		],
																	}),
																	e.jsx(_, {
																		value: "instagram",
																		className: "mt-2",
																		children: e.jsx(Q, {
																			platform: "instagram",
																			platformName: "Instagram",
																			displayName: t.instagram.displayName,
																			onDisplayNameChange: k,
																			campaigns: t.instagram.campaigns,
																			selectedCampaign: a.selectedCampaign,
																			onCampaignChange: $,
																			disabled:
																				a.isStarting ||
																				a.campaignSelectingDisabled,
																		}),
																	}),
																	e.jsx(_, {
																		value: "twitter",
																		className: "mt-2",
																		children: e.jsx(Q, {
																			platform: "twitter",
																			platformName: "X (Twitter)",
																			displayName: t.twitter.displayName,
																			onDisplayNameChange: k,
																			campaigns: t.twitter.campaigns,
																			selectedCampaign: a.selectedCampaign,
																			onCampaignChange: $,
																			disabled:
																				a.isStarting ||
																				a.campaignSelectingDisabled,
																		}),
																	}),
																],
															}),
													],
											  }),
									}),
								}),
								e.jsxs(ce, {
									className: "w-full p-0 flex flex-col",
									children: [
										a.statusMessage &&
											e.jsx("div", {
												className: "w-full",
												children: e.jsx(E, {
													className: "w-full rounded-none",
													children: e.jsx(P, {
														children: a.statusMessage,
													}),
												}),
											}),
										!a.isLoading &&
											e.jsx(e.Fragment, {
												children: a.isAccountActive
													? e.jsx(F, {
															variant: "outline",
															className:
																"p-6 font-bold text-[16px] bg-gray-900 dark:bg-gray-800 border-gray-700 dark:border-gray-600 hover:bg-gray-800 dark:hover:bg-gray-700 hover:text-white text-warning-500 dark:text-warning-400 w-full rounded-none",
															onClick: R,
															disabled: a.isPausing,
															children: a.isPausing
																? "Pausing... Please Wait"
																: "PRESS TO PAUSE CAMPAIGN",
													  })
													: e.jsx(F, {
															variant: "outline",
															className:
																"p-6 font-bold text-[16px] bg-success-600 dark:bg-success-700 border-success-700 dark:border-success-600 hover:bg-success-700 dark:hover:bg-success-600 hover:text-white text-white w-full rounded-none",
															onClick: D,
															disabled:
																a.isStarting ||
																a.isAccountActive ||
																!a.selectedCampaign ||
																w.length === 0,
															children: a.isStarting
																? e.jsxs(e.Fragment, {
																		children: [
																			e.jsx(J, {}),
																			" Starting... Please Wait",
																		],
																  })
																: `PRESS TO START ${a.activeTab.toUpperCase()} CAMPAIGN`,
													  }),
											}),
										e.jsxs("div", {
											className: "flex flex-col space-y-2 mt-2 w-full",
											children: [
												e.jsx(S, {
													className:
														"block text-sm font-medium text-gray-900 dark:text-white mb-2 m-auto",
													children: "Extension Logs",
												}),
												e.jsx("div", {
													className: "log-container w-full custom-scrollbar",
													children:
														Array.isArray(c) &&
														c.length > 0 &&
														c.map((o, r) =>
															e.jsx(
																Te,
																{
																	log: o,
																},
																r
															)
														),
												}),
											],
										}),
									],
								}),
							],
						}),
					}),
				],
			})
		);
	};
// done till here

function Me() {
	return e.jsx(ke, {});
}
xe.createRoot(document.getElementById("root")).render(
	e.jsx(l.StrictMode, {
		children: e.jsx(Me, {}),
	})
);
