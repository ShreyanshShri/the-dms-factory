import { t as ye, c as ve } from "./vendor-BJT0b45B.js";
const Fe = "DM_EVENT";
import { ENV } from "../env.js";
const i = (e, t, o) => {
		let N;
		if (o instanceof Error) N = o.message;
		else if (typeof o == "string") N = o;
		else
			try {
				N = `Unknown Error Type: ${JSON.stringify(o)}`;
			} catch {
				N = "Unknown Error Type: Error in stringifying object";
			}
		const p = {
			timestamp: new Date().toISOString().slice(0, -5).replace("T", " "),
			type: e,
			funcName: t,
			message: N,
		};
		chrome.storage.local.get(["logs"], (s) => {
			const h = [...(s.logs || []), p];
			chrome.storage.local.set(
				{
					logs: h,
				},
				() => {
					chrome.runtime.lastError
						? console.error("Error saving logs:", chrome.runtime.lastError)
						: console.log("Log saved:", p);
				}
			);
		});
	},
	Be = async () =>
		new Promise((e, t) => {
			chrome.storage.local.get(["logs"], (o) => {
				chrome.runtime.lastError
					? t(chrome.runtime.lastError)
					: e((o == null ? void 0 : o.logs) || []);
			});
		});

function Ve(...e) {
	return ye(ve(e));
}
const Se =
		ENV === "PROD"
			? "https://thebuildfluence.com/api/v1/campaign"
			: "http://localhost:5000/api/v1/campaign",
	me = (e) => new Promise((t) => setTimeout(t, e));
async function we(e, t = 0) {
	try {
		try {
			const s = await chrome.tabs.get(e);
			if (!s || !s.url)
				return (
					i("error", "addOverlay", `Tab ${e} is invalid or has no URL`), !1
				);
			await chrome.tabs.update(e, {
				active: !0,
			}),
				await me(500),
				i(
					"info",
					"addOverlay",
					`Attempting to add overlay to tab ${e} (attempt ${t + 1})`
				);
		} catch (s) {
			return (
				i("error", "addOverlay", `Failed to validate/activate tab ${e}: ${s}`),
				!1
			);
		}
		const p = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: () => {
				try {
					const s = document.getElementById("custom-overlay");
					if (
						(s &&
							(s.remove(),
							console.log("BuildFluence: Removed existing overlay")),
						!document.body)
					)
						return (
							console.error("BuildFluence: document.body not available"),
							{
								success: !1,
								error: "document.body not available",
							}
						);
					const g = document.createElement("div");
					return (
						(g.id = "custom-overlay"),
						(g.style.position = "fixed"),
						(g.style.top = "0"),
						(g.style.left = "0"),
						(g.style.width = "100%"),
						(g.style.height = "100%"),
						(g.style.backgroundColor = "rgba(0, 0, 0, 0.93)"),
						(g.style.zIndex = "10000"),
						(g.style.display = "flex"),
						(g.style.justifyContent = "center"),
						(g.style.alignItems = "center"),
						(g.style.color = "#fff"),
						(g.style.fontFamily = "Arial, sans-serif"),
						(g.style.fontSize = "34px"),
						(g.innerHTML = `
            <div style="text-align: center;">
              The <u>BuildFluence</u> is active. Keep this tab open.
            </div>
          `),
						document.body.appendChild(g),
						console.log("BuildFluence: Overlay added successfully"),
						{
							success: !0,
						}
					);
				} catch (s) {
					return (
						console.error("BuildFluence: Error in overlay injection:", s),
						{
							success: !1,
							error: s.message,
						}
					);
				}
			},
		});
		if (p && p[0] && p[0].result) {
			const s = p[0].result;
			if (s.success)
				return (
					i("info", "addOverlay", `Overlay successfully added to tab ${e}`), !0
				);
			throw new Error(s.error || "Unknown injection error");
		} else throw new Error("No result returned from script injection");
	} catch (p) {
		const s = p instanceof Error ? p.message : String(p);
		return (
			i(
				"warning",
				"addOverlay",
				`Failed to add overlay to tab ${e} (attempt ${t + 1}): ${s}`
			),
			t < 3
				? (i(
						"info",
						"addOverlay",
						`Retrying overlay injection for tab ${e} in 1000ms`
				  ),
				  await me(1e3),
				  we(e, t + 1))
				: (i(
						"error",
						"addOverlay",
						`Failed to add overlay to tab ${e} after 4 attempts: ${s}`
				  ),
				  !1)
		);
	}
}

function W(e) {
	return new Promise((t) => setTimeout(t, e));
}

function ie(e, t) {
	return Math.floor(Math.random() * (t - e + 1)) + e;
}

function pe(e, t) {
	var N, p, s, g;
	const o = e == null ? void 0 : e.variants;
	if (o && o.length > 0) {
		const h = Math.floor(Math.random() * o.length);
		let b = String(o[h].message);
		if (t) {
			const K = ((N = t.firstName) == null ? void 0 : N.trim()) || "",
				D = ((p = t.lastName) == null ? void 0 : p.trim()) || "",
				q = ((s = t.username) == null ? void 0 : s.trim()) || "",
				V = ((g = t.fullName) == null ? void 0 : g.trim()) || "",
				R = {};
			V
				? (R["{fullName}"] = V)
				: K && D
				? (R["{fullName}"] = `${K} ${D}`)
				: K && (R["{fullName}"] = K),
				K && (R["{firstName}"] = K),
				D && (R["{lastName}"] = D),
				q && (R["{username}"] = q);
			for (const [L, U] of Object.entries(R)) b = b.split(L).join(U);
			["fullName", "firstName", "lastName", "username"].forEach((L) => {
				const U = `{${L}}`;
				if (b.includes(U)) {
					const le = new RegExp(`\\s*${U}\\s*`, "g");
					(b = b.replace(le, " ")),
						(b = b.replace(/\s*,\s*,\s*/g, ", ")),
						(b = b.replace(/^,\s*|\s*,$/g, ""));
				}
			}),
				(b = b.replace(/^Hey\s+/i, "Hey ")),
				(b = b
					.split(
						`
`
					)
					.map((L) => L.replace(/\s{2,}/g, " ").trim()).join(`
`)),
				(b = b.trim()),
				b.length > 0 && (b = b.charAt(0).toUpperCase() + b.slice(1));
		}
		return b;
	}
	return "";
}

function ke(e, t) {
	var N, p, s, g;
	let o = e;
	if (t) {
		const h = ((N = t.firstName) == null ? void 0 : N.trim()) || "",
			b = ((p = t.lastName) == null ? void 0 : p.trim()) || "",
			K = ((s = t.username) == null ? void 0 : s.trim()) || "",
			D = ((g = t.fullName) == null ? void 0 : g.trim()) || "",
			q = {};
		D
			? (q["{fullName}"] = D)
			: h && b
			? (q["{fullName}"] = `${h} ${b}`)
			: h && (q["{fullName}"] = h),
			h && (q["{firstName}"] = h),
			b && (q["{lastName}"] = b),
			K && (q["{username}"] = K);
		for (const [V, R] of Object.entries(q)) o = o.split(V).join(R);
		["fullName", "firstName", "lastName", "username"].forEach((V) => {
			const R = `{${V}}`;
			if (o.includes(R)) {
				const L = new RegExp(`\\s*${R}\\s*`, "g");
				(o = o.replace(L, " ")),
					(o = o.replace(/\s*,\s*,\s*/g, ", ")),
					(o = o.replace(/^,\s*|\s*,$/g, ""));
			}
		}),
			(o = o.replace(/^Hey\s+/i, "Hey ")),
			(o = o
				.split(
					`
`
				)
				.map((V) => V.replace(/\s{2,}/g, " ").trim()).join(`
`)),
			(o = o.trim()),
			o.length > 0 && (o = o.charAt(0).toUpperCase() + o.slice(1));
	}
	return o;
}

function xe(e) {
	const t = e == null ? void 0 : e.variants;
	if (t && t.length > 0) {
		const o = Math.floor(Math.random() * t.length);
		return t[o];
	}
	return null;
}
const ae = {};
async function Ee(e, t = 3e4) {
	return (
		ae[e] && clearTimeout(ae[e]),
		await chrome.tabs.update(e, {
			active: !0,
		}),
		(ae[e] = setTimeout(() => {
			delete ae[e];
		}, t)),
		() => {
			ae[e] && (clearTimeout(ae[e]), delete ae[e]);
		}
	);
}
async function fe(e) {
	try {
		const [t] = await chrome.scripting.executeScript({
				target: {
					tabId: e,
				},
				func: async () => {
					var b, K, D, q, V;

					function p(R) {
						return new Promise((L) => setTimeout(L, R));
					}
					console.log("Checking for daily limit popup...");
					let s = null;
					const g = [
						"div.x78zum5.xdt5ytf.x1iyjqo2.xg6iff7",
						"section.x78zum5.xdt5ytf.x1iyjqo2.xg6iff7",
						'div[role="dialog"]',
					];
					for (const R of g) {
						const L = document.querySelector(R);
						if (
							L &&
							(b = L.textContent) != null &&
							b.includes("You've reached your daily limit")
						) {
							s = L;
							break;
						}
					}
					if (!s) {
						const R = document.querySelectorAll("div");
						for (const L of R)
							if (
								((K = L.textContent) != null &&
									K.includes("You've reached your daily limit")) ||
								((D = L.textContent) != null && D.includes("daily limit"))
							) {
								let U = L.parentElement;
								for (; U && U !== document.body; ) {
									if (
										U.querySelector('svg[aria-label="close"]') ||
										U.querySelector("button") ||
										U.querySelector('div[role="button"]')
									) {
										s = U;
										break;
									}
									U = U.parentElement;
								}
								if (s) break;
							}
					}
					if (!s)
						return (
							console.log("No daily limit popup detected"),
							{
								success: !0,
								message: "No daily limit popup found",
							}
						);
					console.log("Daily limit popup detected, attempting to close...");
					let h = null;
					if (
						((h =
							(q = s.querySelector('svg[aria-label="close"]')) == null
								? void 0
								: q.closest('div[role="button"]')),
						!h)
					) {
						const R = s.querySelectorAll('div[role="button"], button');
						for (const L of R) {
							const U = L.querySelector("svg");
							if (
								U &&
								(((V = U.getAttribute("aria-label")) != null &&
									V.toLowerCase().includes("close")) ||
									L.innerHTML.includes("polyline") ||
									L.innerHTML.includes("line"))
							) {
								h = L;
								break;
							}
						}
					}
					if (!h) {
						const R = s.querySelectorAll(
							'div[role="button"], button, [tabindex="0"]'
						);
						for (const L of R) {
							const U = L.getBoundingClientRect(),
								le = s.getBoundingClientRect();
							if (U.right > le.right - 50 && U.top < le.top + 50) {
								h = L;
								break;
							}
						}
					}
					if (!h)
						return (
							console.log("Close button not found in popup"),
							{
								success: !1,
								message: "Close button not found",
							}
						);
					console.log("Found close button, attempting to click...");
					try {
						return (
							h.scrollIntoView({
								behavior: "smooth",
								block: "center",
							}),
							await p(300),
							h.focus({
								preventScroll: !0,
							}),
							await p(200),
							h.click(),
							await p(200),
							h.dispatchEvent(
								new MouseEvent("mousedown", {
									bubbles: !0,
									cancelable: !0,
									view: window,
								})
							),
							h.dispatchEvent(
								new MouseEvent("mouseup", {
									bubbles: !0,
									cancelable: !0,
									view: window,
								})
							),
							h.dispatchEvent(
								new MouseEvent("click", {
									bubbles: !0,
									cancelable: !0,
									view: window,
								})
							),
							console.log(
								"Close button clicked, waiting for popup to disappear..."
							),
							await p(1e3),
							document.body.contains(s) &&
							s.offsetParent !== null &&
							getComputedStyle(s).display !== "none"
								? (console.log("Popup still visible after click attempt"),
								  {
										success: !1,
										message: "Popup still visible after close attempt",
								  })
								: (console.log("Popup successfully closed"),
								  {
										success: !0,
										message: "Daily limit popup closed successfully",
								  })
						);
					} catch (R) {
						return (
							console.error("Error clicking close button:", R),
							{
								success: !1,
								message: `Click error: ${R.message}`,
							}
						);
					}
				},
			}),
			{ success: o, message: N } = t.result;
		return (
			o && N !== "No daily limit popup found"
				? i("info", "write", "Successfully closed Instagram daily limit popup")
				: o ||
				  i("warning", "write", `Failed to handle daily limit popup: ${N}`),
			o
		);
	} catch (t) {
		return i("error", "write", `Error handling daily limit popup: ${t}`), !1;
	}
}
async function Ce(e, t = 3e4) {
	const o = Date.now();
	for (; Date.now() - o < t; ) {
		const [N] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: () => {
				const p = Array.from(
						document.querySelectorAll(
							'div[role="textbox"][contenteditable="true"]'
						)
					),
					s = (D) => {
						const q = D.getBoundingClientRect(),
							V = window.getComputedStyle(D);
						return (
							V.display !== "none" &&
							V.visibility !== "hidden" &&
							V.opacity !== "0" &&
							q.width > 0 &&
							q.height > 0 &&
							q.top < window.innerHeight &&
							q.bottom > 0 &&
							q.left < window.innerWidth &&
							q.right > 0
						);
					};
				let g = null;
				for (const D of p)
					if (
						(D.getAttribute("aria-label") || "")
							.toLowerCase()
							.includes("message") ||
						s(D)
					) {
						g = D;
						break;
					}
				if (!g) return !1;
				const h = g.getBoundingClientRect(),
					b = window.getComputedStyle(g),
					K =
						b.display !== "none" &&
						b.visibility !== "hidden" &&
						b.opacity !== "0" &&
						h.width > 0 &&
						h.height > 0 &&
						h.top < window.innerHeight &&
						h.bottom > 0 &&
						h.left < window.innerWidth &&
						h.right > 0;
				if (K)
					try {
						g.scrollIntoView({
							behavior: "smooth",
							block: "center",
						}),
							g.focus({
								preventScroll: !1,
							});
					} catch {}
				return K;
			},
		});
		if (N.result === !0) return !0;
		await new Promise((p) => setTimeout(p, 1e3));
	}
	return !1;
}
async function Ae(e) {
	try {
		const t = `${Se}/suspend-account`,
			o = await fetch(t, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					accountId: e,
				}),
			});
		if (!o.ok) throw new Error(`API response: ${o.status}`);
		i(
			"info",
			"api",
			`Successfully notified API about account suspension for ID: ${e}`
		);
	} catch (t) {
		i("error", "api", `Failed to notify API about account suspension: ${t}`);
	}
}
async function $e(e, t, o) {
	var N;
	try {
		const [p] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: () => {
				const s = document.body.innerText.toLowerCase(),
					h = [
						"your account has been suspended",
						"your account has been disabled",
						"your account has been temporarily locked",
						"we've temporarily restricted",
						"account temporarily blocked",
						"your account has been blocked",
					].filter((b) => s.includes(b));
				return {
					isSuspended: h.length > 0,
					matchingPhrases: h,
				};
			},
		});
		return (N = p.result) != null && N.isSuspended ? (await Ae(o), !0) : !1;
	} catch (p) {
		return console.error("Error checking account suspension:", p), !1;
	}
}
async function Me(e, t) {
	var o, N, p, s, g, h, b, K;
	try {
		console.log("=== PHASE 1: FETCH AUDIO (ISOLATED WORLD) ===");
		const [D] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			args: [t],
			func: async (I) => {
				try {
					console.log("Fetching audio from URL:", I);
					const Q = ``,
						$ = await fetch(Q);
					if (!$.ok)
						throw new Error(`Proxy API failed: ${$.status} ${$.statusText}`);
					const y = await $.json();
					if (!y.base64)
						throw new Error("Proxy API error: No base64 data received");
					return (
						console.log("✅ Audio fetched successfully in isolated world"),
						{
							success: !0,
							base64Data: y.base64,
						}
					);
				} catch (Q) {
					return (
						console.error("❌ Failed to fetch audio:", Q),
						{
							success: !1,
							error: Q.message,
						}
					);
				}
			},
		});
		if (!((o = D.result) != null && o.success))
			return {
				success: !1,
				error: `Failed to fetch audio: ${
					(N = D.result) == null ? void 0 : N.error
				}`,
			};
		console.log("=== PHASE 2: SETUP getUserMedia (MAIN WORLD) ===");
		const [q] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			args: [D.result.base64Data],
			func: async (I) => {
				var Q, $;
				try {
					let y = function (a) {
							try {
								if (
									a.length < 44 ||
									String.fromCharCode(...a.slice(0, 4)) !== "RIFF" ||
									String.fromCharCode(...a.slice(8, 12)) !== "WAVE"
								)
									return null;
								let S = 12;
								for (; S < a.length - 8; ) {
									const Z = String.fromCharCode(...a.slice(S, S + 4)),
										J = new DataView(a.buffer, S + 4, 4).getUint32(0, !0);
									if (Z === "fmt ") {
										const G = new DataView(a.buffer, S + 8, 2).getUint16(0, !0),
											m = new DataView(a.buffer, S + 10, 2).getUint16(0, !0),
											re = new DataView(a.buffer, S + 12, 4).getUint32(0, !0),
											se = new DataView(a.buffer, S + 22, 2).getUint16(0, !0);
										console.log(
											`📊 WAV Format: ${G}, Channels: ${m}, Sample Rate: ${re}, Bits: ${se}`
										);
										let oe = S + 8 + J;
										for (; oe < a.length - 8; ) {
											const X = String.fromCharCode(...a.slice(oe, oe + 4)),
												w = new DataView(a.buffer, oe + 4, 4).getUint32(0, !0);
											if (X === "data") {
												const P = re * m * (se / 8),
													F = w / P;
												return (
													console.log(
														`⏱️ Calculated WAV duration: ${F.toFixed(
															3
														)} seconds`
													),
													Math.round(F * 1e3)
												);
											}
											oe += 8 + w;
										}
										break;
									}
									S += 8 + J;
								}
							} catch (n) {
								console.error("❌ Error parsing WAV header:", n);
							}
							return null;
						},
						f = function (a) {
							let n = a.split(",")[1] || a;
							n = n.replace(/\s+/g, "").trim();
							const c = atob(n),
								S = new Uint8Array(c.length);
							for (let m = 0; m < c.length; m++) S[m] = c.charCodeAt(m);
							let Z = "audio/wav";
							S.length >= 12 &&
								(String.fromCharCode(...S.slice(0, 4)) === "RIFF"
									? (Z = "audio/wav")
									: S[0] === 255 && (S[1] & 224) === 224
									? (Z = "audio/mpeg")
									: String.fromCharCode(...S.slice(4, 8)) === "ftyp" &&
									  (Z = "audio/mp4"));
							const J = y(S),
								G = new Blob([S], {
									type: Z,
								});
							return (
								J !== null &&
									((G._audioDuration = J),
									console.log(`✅ Audio duration detected: ${J}ms`)),
								G
							);
						},
						Y = function () {
							return _;
						};
					console.log("=== VOICE NOTE SETUP START (MAIN WORLD) ===");
					const O =
							($ =
								(Q = navigator.mediaDevices) == null
									? void 0
									: Q.getUserMedia) == null
								? void 0
								: $.bind(navigator.mediaDevices),
						z = URL.createObjectURL,
						_ = f(I);
					return (
						console.log("✅ Custom audio blob created in main world"),
						(window.__customAudioDuration = _._audioDuration || null),
						(navigator.mediaDevices.getUserMedia = async function (a) {
							if (a != null && a.audio) {
								console.log(
									"🎤 Intercepting getUserMedia for audio - injecting custom audio"
								);
								const n = new AudioContext();
								await n.resume();
								const c = n.createMediaStreamDestination(),
									S = Y();
								if (S) {
									const Z = z(S),
										J = new Audio(Z);
									(J.loop = !1),
										await new Promise((m) => {
											(J.onloadeddata = () => m()),
												(J.onerror = () => {
													console.error("❌ Error loading custom audio"), m();
												});
										}),
										n.createMediaElementSource(J).connect(c),
										J.play(),
										console.log("✅ Custom audio injected into stream"),
										(window.__voiceNoteAudioElement = J),
										(window.__voiceNoteContext = n),
										(window.__voiceNoteDestination = c);
								} else
									console.warn("⚠️ No custom audio - stream will be silent");
								return c.stream;
							}
							return O(a);
						}),
						(window.__originalGetUserMedia = O),
						console.log("=== VOICE NOTE SETUP COMPLETE (MAIN WORLD) ==="),
						{
							success: !0,
						}
					);
				} catch (y) {
					console.error("=== VOICE NOTE SETUP ERROR ===", y);
					let f = "Unknown error";
					return (
						y instanceof Error
							? (f = y.message)
							: typeof y == "string"
							? (f = y)
							: y && typeof y == "object" && (f = y.toString()),
						{
							success: !1,
							error: `Setup failed: ${f}`,
						}
					);
				}
			},
			world: "MAIN",
		});
		if (
			(console.log("Setup injection completed in main world"),
			!((p = q.result) != null && p.success))
		)
			return {
				success: !1,
				error:
					((s = q.result) == null ? void 0 : s.error) ||
					"Failed to setup audio in main world",
			};
		console.log("Audio setup completed successfully"), await W(2e3);
		const [V] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: async () => {
				try {
					let I = function (n) {
							return new Promise((c) => setTimeout(c, n));
						},
						Q = function (n) {
							const c = n.getBoundingClientRect(),
								S = window.getComputedStyle(n);
							return (
								S.display !== "none" &&
								S.visibility !== "hidden" &&
								S.opacity !== "0" &&
								c.width > 0 &&
								c.height > 0 &&
								c.top < window.innerHeight &&
								c.bottom > 0 &&
								c.left < window.innerWidth &&
								c.right > 0
							);
						};
					console.log("=== VOICE BUTTON CLICK START ==="),
						console.log("Looking for voice clip button...");
					let $ = null;
					const y = document.querySelector('svg[aria-label="Voice Clip"]');
					if (
						(y &&
							(console.log("Found voice clip SVG"),
							($ = y.closest('[role="button"]')),
							$ && console.log("Found voice button via closest role=button")),
						!$)
					) {
						console.log("Trying fallback method...");
						const n = document.querySelectorAll('[role="button"]');
						for (const c of Array.from(n))
							if (c.querySelector('svg[aria-label="Voice Clip"]')) {
								($ = c), console.log("Found voice button via fallback method");
								break;
							}
					}
					if (!$) {
						console.log("Trying aggressive fallback...");
						const n = document.querySelectorAll("svg");
						for (const c of Array.from(n)) {
							const S = c.getAttribute("aria-label");
							if (S && S.toLowerCase().includes("voice")) {
								const Z = c.closest('[role="button"]');
								if (Z) {
									($ = Z),
										console.log(`Found voice button with aria-label: ${S}`);
									break;
								}
							}
						}
					}
					if (!$)
						return (
							console.log("Voice clip button not found after all attempts"),
							{
								success: !1,
								error: "Voice clip button not found",
							}
						);
					console.log("Voice button found, checking visibility...");
					const f = $.getBoundingClientRect(),
						Y = window.getComputedStyle($);
					if (
						!(
							Y.display !== "none" &&
							Y.visibility !== "hidden" &&
							f.width > 0 &&
							f.height > 0
						)
					)
						return (
							console.log("Voice button found but not visible"),
							{
								success: !1,
								error: "Voice clip button not visible",
							}
						);
					console.log("Voice button is visible, proceeding to click..."),
						console.log("Audio will start automatically when recording begins"),
						console.log("Attempting to click voice button..."),
						$.scrollIntoView({
							behavior: "smooth",
							block: "center",
						}),
						await I(800);
					try {
						$.focus({
							preventScroll: !0,
						}),
							await I(300),
							$.click(),
							console.log("Attempted standard click"),
							await I(200),
							$.dispatchEvent(
								new MouseEvent("mousedown", {
									bubbles: !0,
									cancelable: !0,
									view: window,
								})
							),
							$.dispatchEvent(
								new MouseEvent("mouseup", {
									bubbles: !0,
									cancelable: !0,
									view: window,
								})
							),
							$.dispatchEvent(
								new MouseEvent("click", {
									bubbles: !0,
									cancelable: !0,
									view: window,
								})
							),
							console.log("Attempted mouse events"),
							await I(200),
							$.dispatchEvent(
								new PointerEvent("pointerdown", {
									bubbles: !0,
									cancelable: !0,
								})
							),
							$.dispatchEvent(
								new PointerEvent("pointerup", {
									bubbles: !0,
									cancelable: !0,
								})
							),
							console.log("Attempted pointer events");
					} catch (n) {
						console.error("Error during click attempts:", n);
					}
					console.log("Polling for recording UI to appear...");
					let z = !1,
						_ = 0;
					const a = 10;
					for (; !z && _ < a; ) {
						_++, console.log(`Poll attempt ${_}/${a}`);
						const n = [
							'div[aria-label="Stop recording"]',
							'svg[aria-hidden="true"] rect',
							'div[role="timer"]',
							'[aria-label*="recording"]',
						];
						for (const c of n)
							if (document.querySelector(c)) {
								(z = !0),
									console.log(`Recording UI detected with selector: ${c}`);
								break;
							}
						if (!z) {
							const c = document.body.innerText.toLowerCase();
							(c.includes("0:0") || c.includes("recording")) &&
								((z = !0), console.log("Recording detected via text content"));
						}
						z || (await I(500));
					}
					return z
						? (console.log("Recording started successfully!"),
						  console.log(
								"Audio is handled automatically by getUserMedia override"
						  ),
						  console.log("=== VOICE BUTTON CLICK SUCCESS ==="),
						  {
								success: !0,
						  })
						: (console.log("Recording UI not detected - click may have failed"),
						  {
								success: !1,
								error: "Recording did not start - voice button click failed",
						  });
				} catch (I) {
					return (
						console.error("=== VOICE BUTTON CLICK ERROR ===", I),
						{
							success: !1,
							error: String(I),
						}
					);
				}
			},
		});
		if (!((g = V.result) != null && g.success))
			return {
				success: !1,
				error:
					((h = V.result) == null ? void 0 : h.error) ||
					"Failed to start recording",
			};
		const [R] = await chrome.scripting.executeScript({
				target: {
					tabId: e,
				},
				func: () => window.__customAudioDuration || null,
			}),
			L = R.result,
			U = L || 8e3;
		L
			? console.log("✅ Using detected audio duration:", U, "ms")
			: console.log(
					"⚠️ Using fallback audio duration:",
					U,
					"ms (detection failed)"
			  ),
			console.log("Waiting for audio to finish playing, duration:", U, "ms");
		const le = Math.min(2e3, Math.max(500, U * 0.25));
		await W(U + le);
		const [de] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: async () => {
				var I;
				try {
					let Q = function (a) {
							return new Promise((n) => setTimeout(n, a));
						},
						$ = function (a) {
							const n = a.getBoundingClientRect(),
								c = window.getComputedStyle(a);
							return (
								c.display !== "none" &&
								c.visibility !== "hidden" &&
								c.opacity !== "0" &&
								n.width > 0 &&
								n.height > 0 &&
								n.top < window.innerHeight &&
								n.bottom > 0 &&
								n.left < window.innerWidth &&
								n.right > 0
							);
						};
					console.log("=== STOPPING RECORDING START ===");
					const y = [
						'svg[aria-hidden="true"] rect',
						'div[aria-label="Stop recording"]',
						'button[aria-label="Stop recording"]',
					];
					let f = null;
					const Y = document.querySelectorAll('svg[aria-hidden="true"]');
					for (const a of Array.from(Y))
						if (a.querySelector("rect")) {
							const c = a.closest('[role="button"]');
							if (c && $(c)) {
								(f = c), console.log("Found stop button via SVG rect");
								break;
							}
						}
					if (!f)
						for (const a of y.slice(1)) {
							const n = document.querySelectorAll(a);
							for (const c of Array.from(n)) {
								const S = c;
								if ($(S)) {
									(f = S), console.log(`Found stop button via selector: ${a}`);
									break;
								}
							}
							if (f) break;
						}
					if (!f)
						return (
							console.log("Stop recording button not found"),
							{
								success: !1,
								error: "Stop recording button not found",
							}
						);
					console.log("Stop button found, clicking..."),
						f.scrollIntoView({
							behavior: "smooth",
							block: "center",
						}),
						await Q(300),
						f.focus({
							preventScroll: !0,
						}),
						await Q(200),
						f.click(),
						console.log("Stop button clicked"),
						await Q(3e3);
					let O = null;
					const z = document.querySelectorAll(
						'div[role="button"], button, [role="button"]'
					);
					for (const a of Array.from(z)) {
						const n = a;
						if (
							(((I = n.textContent) == null ? void 0 : I.trim()) || "") ===
								"Send" &&
							$(n)
						) {
							(O = n), console.log("Found send button via text content");
							break;
						}
					}
					if (!O)
						return (
							console.log("Send button not found"),
							{
								success: !1,
								error: "Send button not found",
							}
						);
					console.log("Send button found, clicking..."),
						O.scrollIntoView({
							behavior: "smooth",
							block: "center",
						}),
						await Q(300),
						O.focus({
							preventScroll: !0,
						}),
						await Q(200),
						O.click(),
						console.log("Send button clicked"),
						console.log("Starting cleanup...");
					const _ = window.__originalGetUserMedia;
					return (
						_ &&
							((navigator.mediaDevices.getUserMedia = _),
							console.log("Original getUserMedia restored")),
						console.log("=== STOPPING RECORDING COMPLETE ==="),
						{
							success: !0,
						}
					);
				} catch (Q) {
					return (
						console.error("=== STOPPING RECORDING ERROR ===", Q),
						{
							success: !1,
							error: String(Q),
						}
					);
				}
			},
			world: "MAIN",
		});
		return (b = de.result) != null && b.success
			? (await W(3e3),
			  console.log("Voice note process completed successfully"),
			  {
					success: !0,
			  })
			: {
					success: !1,
					error:
						((K = de.result) == null ? void 0 : K.error) ||
						"Failed to stop and send",
			  };
	} catch (D) {
		console.error("Voice note process failed:", D);
		try {
			await chrome.scripting.executeScript({
				target: {
					tabId: e,
				},
				func: () => {
					console.log("Emergency cleanup triggered");
					const q = window.__originalGetUserMedia;
					q && (navigator.mediaDevices.getUserMedia = q),
						console.log("Emergency cleanup completed");
				},
				world: "MAIN",
			});
		} catch (q) {
			console.error("Error during emergency cleanup:", q);
		}
		return {
			success: !1,
			error: String(D),
		};
	}
}
async function Te(e, t, o, N, p) {
	var g, h, b, K, D, q, V, R, L, U, le, de, I, Q, $, y, f, Y, O;
	const s = await Ee(e, 12e4);
	try {
		const z = await chrome.windows.get((await chrome.tabs.get(e)).windowId);
		for (let w = 0; w < 2; w++)
			try {
				await chrome.tabs.update(e, {
					active: !0,
					url: `https://www.instagram.com/${t}`,
				});
				break;
			} catch (P) {
				if (
					(g = P.message) != null &&
					g.includes("Tabs cannot be edited right now")
				)
					await W(5e3);
				else throw P;
			}
		await W(ie(2e3, 4e3)), await fe(e);
		let _ = 0;
		for (; _ < 2; ) {
			const w = await chrome.tabs.get(e);
			if (w.active && w.status === "complete") break;
			await W(2e3), _++;
		}
		let a = "unknown";
		try {
			const w = await chrome.storage.local.get("accountId");
			w.accountId && (a = w.accountId);
		} catch (w) {
			console.error("Failed to get accountId from storage:", w);
		}
		if (await $e(e, t, a))
			return (
				i(
					"error",
					"write",
					`Account appears to be suspended - aborting message to ${t}`
				),
				{
					success: !1,
					message: "Account appears to be suspended",
				}
			);
		await W(ie(4e3, 6e3)), await fe(e);
		const c = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: () => {
				var w, P;
				try {
					let F;
					const j = document.querySelector(
						".x1lliihq.x193iq5w.x6ikm8r.x10wlt62.xlyipyv.xuxw1ft"
					);
					if ((j && j.textContent && (F = j.textContent.trim()), !F)) {
						const l = document.querySelector(
							"h2.x1lliihq.x1plvlek.xryxfnj > span.x1lliihq.x193iq5w.x6ikm8r.x10wlt62.xlyipyv.xuxw1ft"
						);
						l && l.textContent && (F = l.textContent.trim());
					}
					if (!F) {
						const u = window.location.pathname.match(/^\/([\w\.]+)/);
						u && u[1] && (F = u[1]);
					}
					let v;
					const H = document.querySelector(
						"div.x9f619.xjbqb8w span.x1lliihq.x1plvlek.xryxfnj"
					);
					if ((H && H.textContent && (v = H.textContent.trim()), !v)) {
						const l = [
							"section.xc3tme8 span.x1lliihq.x1plvlek.xryxfnj",
							"div.x9f619.xjbqb8w.x168nmei span.x1lliihq.x1plvlek.xryxfnj",
							"div.x78zum5.xl56j7k span.x1lliihq.x1plvlek.xryxfnj",
						];
						for (const u of l) {
							const T = document.querySelectorAll(u);
							for (const ne of Array.from(T)) {
								const B = (w = ne.textContent) == null ? void 0 : w.trim();
								if (B && B.length > 1 && !B.includes("@") && !/^\d+$/.test(B)) {
									v = B;
									break;
								}
							}
							if (v) break;
						}
					}
					if (!v) {
						const l = document.querySelectorAll(
							"span._ap3a._aaco._aacu._aacx._aad7._aade, div.x9f619.xjbqb8w span"
						);
						for (const u of Array.from(l)) {
							const T = (P = u.textContent) == null ? void 0 : P.trim();
							if (
								T &&
								T.length > 1 &&
								!T.includes("@") &&
								!T.toLowerCase().includes("follow") &&
								!T.toLowerCase().includes("posts") &&
								!T.toLowerCase().includes("follower") &&
								!T.includes("#")
							) {
								v = T;
								break;
							}
						}
					}
					let M, ee;
					if (v) {
						const l = v.split(" ");
						l.length >= 1 &&
							(l[0].toLowerCase() === "the" && l.length >= 2
								? l.length >= 3
									? ((M = l[0] + " " + l[1]), (ee = l.slice(2).join(" ")))
									: ((M = l[0]), (ee = l[1]))
								: ((M = l[0]), l.length >= 2 && (ee = l.slice(1).join(" "))));
					}
					return (
						console.log("Extracted profile data:", {
							firstName: M,
							lastName: ee,
							username: F,
							fullName: v,
						}),
						{
							firstName: M,
							lastName: ee,
							username: F,
							fullName: v,
						}
					);
				} catch (F) {
					return (
						console.error("Error extracting Instagram profile data:", F), {}
					);
				}
			},
		});
		if (
			((await we(e)) ||
				i(
					"warning",
					"write",
					`Failed to add overlay for ${t}, continuing anyway`
				),
			i(
				"info",
				"write",
				`Starting DM process for user: ${t} (${
					((b = (h = c[0]) == null ? void 0 : h.result) == null
						? void 0
						: b.fullName) || "unknown name"
				})`
			),
			(o == null ? void 0 : o.followUser) == !0)
		) {
			i("info", "write", `Attempting to follow user: ${t}`), await fe(e);
			try {
				const P = chrome.scripting.executeScript({
						target: {
							tabId: e,
						},
						func: async () => {
							var T, ne, B, C;

							function v(d) {
								return new Promise((r) => setTimeout(r, d));
							}

							function H(d) {
								const r = d.getBoundingClientRect(),
									k = window.getComputedStyle(d);
								return (
									k.display !== "none" &&
									k.visibility !== "hidden" &&
									k.opacity !== "0" &&
									r.width > 0 &&
									r.height > 0 &&
									r.top < window.innerHeight &&
									r.bottom > 0 &&
									r.left < window.innerWidth &&
									r.right > 0
								);
							}

							function M(d) {
								return new Promise((r) => {
									try {
										d.scrollIntoView({
											behavior: "smooth",
											block: "center",
										}),
											setTimeout(() => {
												try {
													d.focus({
														preventScroll: !0,
													}),
														setTimeout(() => {
															const k = d.getBoundingClientRect(),
																x = Math.floor(k.left + k.width / 2),
																E = Math.floor(k.top + k.height / 2),
																A = {
																	bubbles: !0,
																	cancelable: !0,
																	view: window,
																	clientX: x,
																	clientY: E,
																};
															d.dispatchEvent(new MouseEvent("pointerdown", A)),
																d.dispatchEvent(new MouseEvent("mousedown", A)),
																d.dispatchEvent(new MouseEvent("pointerup", A)),
																d.dispatchEvent(new MouseEvent("mouseup", A)),
																d.dispatchEvent(new MouseEvent("click", A)),
																r(!0);
														}, 200);
												} catch {
													r(!1);
												}
											}, 300);
									} catch {
										r(!1);
									}
								});
							}
							console.log("Starting follow process..."), await v(2e3);
							const ee = [
								'button[type="button"]',
								'div[role="button"]',
								"button",
								"header button",
								"section button",
								"article button",
								".x1i10hfl.xjbqb8w",
								".x1i10hfl.x1qjc9v5",
								'button[aria-label*="Follow"]',
								'div[aria-label*="Follow"]',
							];
							let l = null,
								u = "unknown";
							for (const d of ee) {
								const r = document.querySelectorAll(d);
								for (const k of Array.from(r)) {
									const x = k,
										E =
											((T = x.textContent) == null
												? void 0
												: T.trim().toLowerCase()) || "",
										A =
											((ne = x.getAttribute("aria-label")) == null
												? void 0
												: ne.toLowerCase()) || "";
									if (H(x))
										if (E === "follow" || A.includes("follow")) {
											(l = x),
												(u = "follow"),
												console.log(
													`Found follow button with text: "${E}" or aria-label: "${A}"`
												);
											break;
										} else {
											if (E === "following" || A.includes("following"))
												return (
													(u = "following"),
													console.log(
														`User is already being followed (text: "${E}" or aria-label: "${A}")`
													),
													{
														success: !0,
														reason: "already_following",
													}
												);
											if (E === "requested" || A.includes("requested"))
												return (
													(u = "requested"),
													console.log(
														`Follow request already sent (text: "${E}" or aria-label: "${A}")`
													),
													{
														success: !0,
														reason: "already_requested",
													}
												);
										}
								}
								if (l) break;
							}
							if (!l) {
								console.log(
									"No follow button found by text, searching by position..."
								);
								const d = document.querySelectorAll("header, section");
								for (const r of Array.from(d)) {
									const k = r.querySelectorAll('button, div[role="button"]');
									for (const x of Array.from(k)) {
										const E = x;
										if (H(E)) {
											const A =
												((B = E.textContent) == null
													? void 0
													: B.trim().toLowerCase()) || "";
											if (
												A.length > 0 &&
												A.length < 20 &&
												["follow", "following", "requested"].some((te) =>
													A.includes(te)
												)
											) {
												(l = E),
													(u = A),
													console.log(
														`Found potential follow button by position with text: "${A}"`
													);
												break;
											}
										}
									}
									if (l) break;
								}
							}
							if (!l)
								return (
									console.log("No follow button found"),
									{
										success: !1,
										reason: "no_follow_button",
									}
								);
							if (u === "follow")
								if ((console.log("Clicking follow button..."), await M(l))) {
									await v(1500);
									const r =
										((C = l.textContent) == null
											? void 0
											: C.trim().toLowerCase()) || "";
									return r === "following" || r === "requested"
										? (console.log(
												`Follow successful, button now shows: "${r}"`
										  ),
										  {
												success: !0,
												reason: "followed",
										  })
										: (console.log(
												`Follow button clicked but state unclear: "${r}"`
										  ),
										  {
												success: !0,
												reason: "follow_attempted",
										  });
								} else
									return (
										console.log("Failed to click follow button"),
										{
											success: !1,
											reason: "click_failed",
										}
									);
							else
								return (
									console.log(`Follow button in state: ${u}`),
									{
										success: !0,
										reason: u,
									}
								);
						},
					}),
					F = new Promise((v) => {
						setTimeout(() => {
							v([
								{
									result: {
										success: !1,
										reason: "timeout",
									},
								},
							]);
						}, 1e4);
					}),
					j = await Promise.race([P, F]);
				if ((D = (K = j[0]) == null ? void 0 : K.result) != null && D.success)
					switch (j[0].result.reason) {
						case "followed":
							i("info", "write", `Successfully followed ${t}`);
							break;
						case "already_following":
							i("info", "write", `Already following ${t}`);
							break;
						case "already_requested":
							i("info", "write", `Follow request already sent to ${t}`);
							break;
						case "follow_attempted":
							i(
								"info",
								"write",
								`Follow attempt made for ${t} (verification unclear)`
							);
							break;
					}
				else {
					const v =
						((V = (q = j[0]) == null ? void 0 : q.result) == null
							? void 0
							: V.reason) || "unknown";
					i("warning", "write", `Could not follow ${t}: ${v}`);
				}
			} catch (w) {
				i("warning", "write", `Error in follow process for ${t}: ${w}`);
			}
			await W(ie(2e3, 4e3));
		}
		if ((o == null ? void 0 : o.autoLikeStory) == !0) {
			i("info", "write", `Attempting to like story for user: ${t}`);
			try {
				await chrome.tabs.update(e, {
					active: !0,
					url: `https://www.instagram.com/stories/${t}/`,
				}),
					await W(ie(3e3, 5e3));
				const w = 15e3,
					P = chrome.scripting.executeScript({
						target: {
							tabId: e,
						},
						func: async () => {
							var v, H;
							try {
								let M = function (d) {
										return new Promise((r) => setTimeout(r, d));
									},
									ee = function (d) {
										const r = d.getBoundingClientRect(),
											k = window.getComputedStyle(d);
										return (
											k.display !== "none" &&
											k.visibility !== "hidden" &&
											k.opacity !== "0" &&
											r.width > 0 &&
											r.height > 0 &&
											r.top < window.innerHeight &&
											r.bottom > 0 &&
											r.left < window.innerWidth &&
											r.right > 0
										);
									};
								if (!window.location.href.includes("/stories/"))
									return {
										success: !1,
										reason: "not_on_story_page",
									};
								const u = document.body.innerText.toLowerCase();
								if (
									u.includes("story is unavailable") ||
									u.includes("story not found") ||
									u.includes("no story to show") ||
									u.includes("story cannot be loaded") ||
									u.includes("content not available")
								)
									return {
										success: !1,
										reason: "no_story",
									};
								await M(1500);
								let T = 0;
								const ne = 3;
								for (; T < ne; ) {
									const d = [
										'div[role="button"]:has-text("View story")',
										'button:has-text("View story")',
										'[role="button"]',
									];
									let r = null;
									const k = document.querySelectorAll(
										'div[role="button"], button, [role="button"]'
									);
									for (const x of Array.from(k)) {
										const E = x;
										if (
											(
												((v = E.textContent) == null
													? void 0
													: v.trim().toLowerCase()) || ""
											).includes("view story") &&
											ee(E)
										) {
											r = E;
											break;
										}
									}
									if (r) {
										console.log("Found 'View story' button, clicking it"),
											r.scrollIntoView({
												behavior: "smooth",
												block: "center",
											}),
											await M(300),
											r.focus({
												preventScroll: !0,
											}),
											await M(200),
											r.click(),
											await M(2e3);
										break;
									} else break;
									T++, await M(500);
								}
								let B = 0;
								const C = 5;
								for (; B < C; ) {
									const d = [
										'svg[aria-label="Like"]',
										'svg[aria-label="Unlike"]',
										'button svg[aria-label="Like"]',
										'div[role="button"] svg[aria-label="Like"]',
										'div.x78zum5.xvc5jky svg[aria-label="Like"]',
										'span svg[aria-label="Like"]',
									];
									let r = null;
									for (const k of d) {
										const x = document.querySelectorAll(k);
										for (const E of Array.from(x)) {
											const A = E.closest('[role="button"]');
											if (A && ee(A)) {
												r = A;
												break;
											}
										}
										if (r) break;
									}
									if (r) {
										const k = r.querySelector("svg");
										return ((H =
											k == null ? void 0 : k.getAttribute("aria-label")) == null
											? void 0
											: H.toLowerCase()) === "unlike"
											? (console.log("Story is already liked"),
											  {
													success: !0,
													reason: "already_liked",
											  })
											: (r.scrollIntoView({
													behavior: "smooth",
													block: "center",
											  }),
											  await M(300),
											  r.focus({
													preventScroll: !0,
											  }),
											  await M(200),
											  r.click(),
											  console.log("Successfully liked the story"),
											  await M(1e3),
											  {
													success: !0,
													reason: "liked",
											  });
									}
									B++, await M(800);
								}
								return {
									success: !1,
									reason: "like_button_not_found",
								};
							} catch (M) {
								return (
									console.error("Error in story liking:", M),
									{
										success: !1,
										reason: "error",
										error: String(M),
									}
								);
							}
						},
					}),
					F = new Promise((v) => {
						setTimeout(() => {
							v([
								{
									result: {
										success: !1,
										reason: "timeout",
									},
								},
							]);
						}, w);
					}),
					j = await Promise.race([P, F]);
				if ((L = (R = j[0]) == null ? void 0 : R.result) != null && L.success) {
					const v = j[0].result.reason;
					v === "liked"
						? i("info", "write", `Successfully liked story for ${t}`)
						: v === "already_liked" &&
						  i("info", "write", `Story already liked for ${t}`);
				} else {
					const v =
						((le = (U = j[0]) == null ? void 0 : U.result) == null
							? void 0
							: le.reason) || "unknown";
					i("warning", "write", `Could not like story for ${t}: ${v}`);
				}
			} catch (w) {
				i("warning", "write", `Error in story liking process for ${t}: ${w}`);
			}
			try {
				await chrome.tabs.update(e, {
					active: !0,
					url: `https://www.instagram.com/${t}`,
				}),
					await W(ie(1500, 3e3)),
					i(
						"info",
						"write",
						`Continuing to DM process for ${t} after story attempt`
					);
			} catch (w) {
				i(
					"error",
					"write",
					`Failed to navigate back to profile after story attempt: ${w}`
				);
			}
		}
		if ((o == null ? void 0 : o.autoLikeNewestPost) == !0) {
			i("info", "write", `Attempting to like newest post for user: ${t}`);
			try {
				const P = chrome.scripting.executeScript({
						target: {
							tabId: e,
						},
						func: async () => {
							var v;
							try {
								let H = function (B) {
										return new Promise((C) => setTimeout(C, B));
									},
									M = function (B) {
										const C = B.getBoundingClientRect(),
											d = window.getComputedStyle(B);
										return (
											d.display !== "none" &&
											d.visibility !== "hidden" &&
											d.opacity !== "0" &&
											C.width > 0 &&
											C.height > 0 &&
											C.top < window.innerHeight &&
											C.bottom > 0 &&
											C.left < window.innerWidth &&
											C.right > 0
										);
									};
								const ee = [
									'div._ac7v a[href*="/p/"], div._ac7v a[href*="/reel/"]',
									'div.x1lliihq.x1n2onr6.xh8yej3.x4gyw5p a[href*="/p/"], div.x1lliihq.x1n2onr6.xh8yej3.x4gyw5p a[href*="/reel/"]',
									'a._a6hd[href*="/p/"], a._a6hd[href*="/reel/"]',
									'a.x1i10hfl[href*="/p/"], a.x1i10hfl[href*="/reel/"]',
								];
								let l = null;
								for (const B of ee) {
									const C = document.querySelectorAll(B);
									for (const d of Array.from(C)) {
										const r = d;
										if (M(r) && r.getAttribute("href")) {
											l = r;
											break;
										}
									}
									if (l) break;
								}
								if (!l)
									return (
										console.log("No posts found for this user"),
										{
											success: !1,
											reason: "no_posts",
										}
									);
								const u = l.getAttribute("href");
								console.log("Found first post:", u),
									l.scrollIntoView({
										behavior: "smooth",
										block: "center",
									}),
									await H(1e3),
									l.focus({
										preventScroll: !0,
									}),
									await H(500),
									l.click(),
									await H(2500);
								let T = 0;
								const ne = 6;
								for (; T < ne; ) {
									const B = [
										'svg[aria-label="Like"]',
										'svg[aria-label="Unlike"]',
										'button svg[aria-label="Like"]',
										'div[role="button"] svg[aria-label="Like"]',
										'section[role="dialog"] svg[aria-label="Like"]',
										'article svg[aria-label="Like"]',
									];
									let C = null;
									for (const d of B) {
										const r = document.querySelectorAll(d);
										for (const k of Array.from(r)) {
											const x = k.closest('[role="button"]');
											if (x && M(x)) {
												C = x;
												break;
											}
										}
										if (C) break;
									}
									if (C) {
										const d = C.querySelector("svg");
										return ((v =
											d == null ? void 0 : d.getAttribute("aria-label")) == null
											? void 0
											: v.toLowerCase()) === "unlike"
											? (console.log("Post is already liked"),
											  document.dispatchEvent(
													new KeyboardEvent("keydown", {
														key: "Escape",
													})
											  ),
											  await H(1e3),
											  {
													success: !0,
													reason: "already_liked",
											  })
											: (C.scrollIntoView({
													behavior: "smooth",
													block: "center",
											  }),
											  await H(300),
											  C.focus({
													preventScroll: !0,
											  }),
											  await H(200),
											  C.click(),
											  console.log("Successfully liked the post"),
											  await H(1e3),
											  document.dispatchEvent(
													new KeyboardEvent("keydown", {
														key: "Escape",
													})
											  ),
											  await H(1e3),
											  {
													success: !0,
													reason: "liked",
											  });
									}
									T++, await H(800);
								}
								return (
									document.dispatchEvent(
										new KeyboardEvent("keydown", {
											key: "Escape",
										})
									),
									await H(1e3),
									{
										success: !1,
										reason: "like_button_not_found",
									}
								);
							} catch (H) {
								console.error("Error in post liking:", H);
								try {
									document.dispatchEvent(
										new KeyboardEvent("keydown", {
											key: "Escape",
										})
									);
								} catch (M) {
									console.warn("Failed to close post:", M);
								}
								return {
									success: !1,
									reason: "error",
									error: String(H),
								};
							}
						},
					}),
					F = new Promise((v) => {
						setTimeout(() => {
							v([
								{
									result: {
										success: !1,
										reason: "timeout",
									},
								},
							]);
						}, 12e3);
					}),
					j = await Promise.race([P, F]);
				if (
					(I = (de = j[0]) == null ? void 0 : de.result) != null &&
					I.success
				) {
					const v = j[0].result.reason;
					v === "liked"
						? i("info", "write", `Successfully liked newest post for ${t}`)
						: v === "already_liked" &&
						  i("info", "write", `Newest post already liked for ${t}`);
				} else {
					const v =
						(($ = (Q = j[0]) == null ? void 0 : Q.result) == null
							? void 0
							: $.reason) || "unknown";
					i("warning", "write", `Could not like newest post for ${t}: ${v}`);
				}
			} catch (w) {
				i("warning", "write", `Error in post liking process for ${t}: ${w}`);
			}
			try {
				await chrome.tabs.update(e, {
					active: !0,
					url: `https://www.instagram.com/${t}`,
				}),
					await W(ie(1500, 3e3)),
					i(
						"info",
						"write",
						`Continuing to DM process for ${t} after post attempt`
					);
			} catch (w) {
				i(
					"error",
					"write",
					`Failed to navigate back to profile after post attempt: ${w}`
				);
			}
		}
		await W(ie(8e3, 12e3)),
			await chrome.tabs.update(e, {
				active: !0,
			});
		const Z = async (w = 2) => {
			for (let P = 0; P < w; P++)
				try {
					if (
						(P === 0 &&
							(await chrome.tabs.update(e, {
								active: !0,
							}),
							await W(1e3)),
						(
							await chrome.scripting.executeScript({
								target: {
									tabId: e,
								},
								func: async () => {
									const j = (l) => {
											const u = l.getBoundingClientRect(),
												T = window.getComputedStyle(l);
											return (
												T.display !== "none" &&
												T.visibility !== "hidden" &&
												T.opacity !== "0" &&
												u.width > 0 &&
												u.height > 0 &&
												u.top < window.innerHeight &&
												u.bottom > 0 &&
												u.left < window.innerWidth &&
												u.right > 0
											);
										},
										v = (l) => {
											try {
												return (
													l.scrollIntoView({
														behavior: "smooth",
														block: "center",
													}),
													new Promise((u) => {
														setTimeout(() => {
															try {
																l.focus({
																	preventScroll: !0,
																}),
																	l.click(),
																	setTimeout(() => {
																		l.dispatchEvent(
																			new MouseEvent("click", {
																				bubbles: !0,
																				cancelable: !0,
																				view: window,
																			})
																		),
																			setTimeout(() => {
																				l.dispatchEvent(
																					new MouseEvent("mousedown", {
																						bubbles: !0,
																						cancelable: !0,
																						view: window,
																					})
																				),
																					l.dispatchEvent(
																						new MouseEvent("mouseup", {
																							bubbles: !0,
																							cancelable: !0,
																							view: window,
																						})
																					),
																					u(!0);
																			}, 200);
																	}, 200);
															} catch (T) {
																console.error("Click attempt failed:", T),
																	u(!1);
															}
														}, 500);
													})
												);
											} catch (u) {
												return (
													console.error("Click failed:", u), Promise.resolve(!1)
												);
											}
										},
										H = async () => {
											var T, ne;
											console.log(
												"Attempting to find message button through options menu..."
											);
											const l = [
												'div[role="button"] svg[aria-label="Options"]',
												'[role="button"] svg[aria-label="Options"]',
												'svg[aria-label="Options"]',
												'button svg[aria-label="Options"]',
												'div.x1q0g3np.x2lah0s svg[aria-label="Options"]',
												'div.x1q0g3np.x2lah0s div[role="button"] svg[aria-label="Options"]',
											];
											let u = null;
											for (const B of l) {
												const C = document.querySelector(B);
												if (
													C &&
													((u = C.closest('[role="button"]')), u && j(u))
												) {
													console.log(
														`Found options button with selector: ${B}`
													);
													break;
												}
											}
											if (!u || !j(u)) {
												console.log(
													"Options button not found via aria-label, trying structural detection..."
												);
												const B = Array.from(document.querySelectorAll("svg"));
												for (const C of B)
													try {
														const d = C.querySelectorAll("circle"),
															r =
																((ne =
																	(T = C.querySelector("title")) == null
																		? void 0
																		: T.textContent) == null
																	? void 0
																	: ne.toLowerCase()) || "";
														if (
															(d && d.length === 3) ||
															r.includes("options")
														) {
															const k = C.closest(
																'[role="button"], button, div[role="button"]'
															);
															if (k && j(k)) {
																u = k;
																break;
															}
														}
													} catch {}
												if (!u || !j(u))
													return (
														console.log(
															"Options button not found or not visible after structural detection"
														),
														!1
													);
											}
											return (
												console.log("Clicking options button..."),
												(await v(u))
													? new Promise((B) => {
															let C = 0;
															const d = 2,
																r = () => {
																	var ce;
																	C++,
																		console.log(
																			`Checking for menu items, attempt ${C}/${d}`
																		);
																	const k = document.querySelector(
																		'div[role="dialog"].x1ja2u2z, div[role="dialog"], [role="menu"]'
																	);
																	if (!k) {
																		console.log("Dialog not found"),
																			C < d ? setTimeout(r, 800) : B(!1);
																		return;
																	}
																	const E = Array.from(
																		k.querySelectorAll(
																			'button, [tabindex="0"], .xjbqb8w, [role="menuitem"], a[role="menuitem"], div[role="button"]'
																		)
																	).filter((te) => {
																		var ge;
																		const be =
																			((ge = te.textContent) == null
																				? void 0
																				: ge.trim().toLowerCase()) || "";
																		return j(te)
																			? [
																					"send message",
																					"message",
																					"send a message",
																					"direct message",
																					"send a chat",
																					"send message…",
																					"send message...",
																			  ].some((he) => be.includes(he))
																			: !1;
																	});
																	let A = null;
																	if (
																		(E.length > 1
																			? (A = E[1])
																			: E.length === 1 && (A = E[0]),
																		A)
																	) {
																		console.log(
																			`Found send message button with text: "${
																				(ce = A.textContent) == null
																					? void 0
																					: ce.trim()
																			}"`
																		),
																			v(A).then((te) => {
																				console.log(
																					`Send message button click result: ${te}`
																				),
																					B(te);
																			});
																		return;
																	}
																	C < d
																		? (console.log(
																				"Send message button not found yet, retrying..."
																		  ),
																		  setTimeout(r, 1e3))
																		: (console.log(
																				"Send message button not found after all attempts"
																		  ),
																		  B(!1));
																};
															setTimeout(r, 1400);
													  })
													: (console.log("Failed to click options button"), !1)
											);
										},
										M = () => {
											var u, T;
											console.log("Looking for direct message button...");
											const l = [
												"button",
												'[role="button"]',
												'div[role="button"]',
												'a[role="button"]',
												'[aria-label*="message" i]',
												'[data-testid*="message"]',
											];
											for (const ne of l) {
												const C = Array.from(
													document.querySelectorAll(ne)
												).filter((d) => j(d));
												for (const d of C) {
													const r =
															((u = d.textContent) == null
																? void 0
																: u.trim().toLowerCase()) || "",
														k =
															((T = d.getAttribute("aria-label")) == null
																? void 0
																: T.toLowerCase()) || "";
													if (
														[
															"message",
															"send message",
															"direct message",
															"send a message",
														].some(
															(A) =>
																r === A ||
																r.includes(A) ||
																k === A ||
																k.includes(A)
														)
													)
														return (
															console.log(
																`Found direct message button with text: "${r}" or aria-label: "${k}"`
															),
															d
														);
												}
											}
											return (
												console.log("No direct message button found"), null
											);
										};
									if (
										(console.log("Trying options menu first..."),
										(await H()) &&
											(console.log("Successfully used options menu fallback"),
											await new Promise((u) => setTimeout(u, 1200)),
											!!document.querySelector(
												'div[role="textbox"][contenteditable="true"]'
											) ||
												(document.dispatchEvent(
													new KeyboardEvent("keydown", {
														key: "Escape",
													})
												),
												await new Promise((u) => setTimeout(u, 600)),
												document.querySelector(
													'div[role="textbox"][contenteditable="true"]'
												))))
									)
										return !0;
									console.log(
										"Attempting direct message button as fallback..."
									);
									const ee = M();
									return ee && (await v(ee))
										? !0
										: (console.log(
												"Both direct button and options menu fallback failed"
										  ),
										  !1);
								},
								world: "MAIN",
							})
						)[0].result == !0)
					)
						return !0;
					await W(7e3);
				} catch (F) {
					console.error(`Attempt ${P + 1} failed:`, F);
				}
			return !1;
		};
		if (
			(i(
				"info",
				"write",
				`Attempting to find and click message button for ${t}`
			),
			await fe(e),
			!(await Z()))
		)
			throw (
				(i(
					"error",
					"write",
					`Failed to find message button after multiple attempts for ${t}. Tried both direct button and options menu fallback.`
				),
				new Error("Failed to find message button after multiple attempts"))
			);
		if (
			(i("info", "write", `Successfully clicked message button for ${t}`),
			!(await Ce(e, 3e4)))
		)
			return (
				i("error", "write", `Failed to open messages window: ${t}`),
				{
					success: !1,
					message: `Failed to open messages window: ${t}`,
				}
			);
		const m = p ? null : xe(o),
			re = m == null ? void 0 : m.voiceNoteUrl;
		if (!p && o != null && o.sendVoiceNote && re) {
			i(
				"info",
				"write",
				`Attempting to send voice note to ${t} using variant URL`
			);
			try {
				const w = await Me(e, re);
				if (w.success)
					return (
						i("info", "write", `Successfully sent voice note to ${t}`),
						{
							success: !0,
							message: "Voice note sent successfully",
						}
					);
				i("warning", "write", `Failed to send voice note to ${t}: ${w.error}`);
			} catch (w) {
				i("error", "write", `Error sending voice note to ${t}: ${w}`);
			}
		}
		let se = p
			? N
			: m != null && m.message
			? ke(m.message, (y = c[0]) == null ? void 0 : y.result)
			: pe(o, (f = c[0]) == null ? void 0 : f.result);
		(se = se
			.replace(
				/\r\n/g,
				`
`
			)
			.replace(
				/\r/g,
				`
`
			)),
			await chrome.tabs.update(e, {
				active: !0,
			}),
			await W(1e3);
		let oe = !1,
			X = 0;
		for (; !oe && X < 3; ) {
			X++, await fe(e);
			try {
				X === 1 &&
					(await chrome.tabs.update(e, {
						active: !0,
					}),
					await W(1e3));
				const [w] = await chrome.scripting.executeScript({
					target: {
						tabId: e,
					},
					args: [se],
					func: async (P) => {
						var r, k;

						function F(x) {
							return new Promise((E) => setTimeout(E, x));
						}

						function j(x, E) {
							return Math.floor(Math.random() * (E - x + 1)) + x;
						}

						function v(x) {
							const E = /^[a-z]$/i.test(x),
								A = /^[0-9]$/.test(x);
							return E
								? `Key${x.toUpperCase()}`
								: A
								? `Digit${x}`
								: x === " "
								? "Space"
								: "Unidentified";
						}
						async function H(x, E) {
							return new Promise(async (A) => {
								try {
									x.scrollIntoView({
										behavior: "smooth",
										block: "center",
									}),
										await F(j(300, 700)),
										x.focus({
											preventScroll: !0,
										}),
										await F(j(300, 600)),
										(x.textContent = ""),
										await F(j(200, 400));
									const ce = E.split(`
`);
									for (let te = 0; te < ce.length; te++)
										ce[te].length > 0 &&
											document.execCommand("insertText", !1, ce[te]),
											te < ce.length - 1 &&
												(document.execCommand("insertLineBreak", !1),
												await F(j(100, 250)));
									await F(j(400, 800)),
										x.dispatchEvent(
											new KeyboardEvent("keydown", {
												key: "Enter",
												code: "Enter",
												keyCode: 13,
												which: 13,
												bubbles: !0,
												cancelable: !0,
											})
										),
										setTimeout(() => {
											try {
												const te = document.querySelector(
													'button[type="submit"], [aria-label*="send" i], [data-testid*="send"]'
												);
												te && te.click();
											} catch {}
										}, 400),
										A();
								} catch {
									A();
								}
							});
						}
						let M = null,
							ee = 0;
						const l = 3;
						for (; !M && ee < l; )
							(M = document.querySelector(
								'div[aria-label="Message"][role="textbox"][contenteditable="true"]'
							)),
								M || (await F(1e3), ee++);
						if (!M)
							throw new Error(
								"Message input not found after multiple attempts"
							);
						M.scrollIntoView({
							behavior: "smooth",
							block: "center",
						}),
							await F(500),
							M.focus({
								preventScroll: !0,
							}),
							await F(700),
							(M.textContent = ""),
							await F(j(1500, 2500)),
							await H(M, P),
							await F(3500);
						const u = document.querySelectorAll("*");
						for (const x of u)
							if (
								(x.textContent || "").includes(
									P.substring(0, Math.min(15, P.length))
								)
							)
								return {
									success: !0,
									method: "content-found",
								};
						const T = document.querySelector(
							'div[aria-label="Message"][role="textbox"][contenteditable="true"]'
						);
						if (!T || T.textContent === "")
							return {
								success: !0,
								method: "input-cleared",
							};
						if (
							document.querySelectorAll(
								'[aria-label*="seen"], [aria-label*="sent"], [data-testid*="sent"]'
							).length > 0
						)
							return {
								success: !0,
								method: "sent-indicator",
							};
						const B = document.querySelectorAll("*");
						for (const x of B) {
							const E =
								((r = x.textContent) == null ? void 0 : r.toLowerCase()) || "";
							if (E.includes("invitation sent") || E.includes("invite sent"))
								return {
									success: !0,
									method: "invitation-sent",
								};
						}
						const C = document.querySelectorAll(
							'.x193iq5w, .xeuugli, .x1lliihq, .x6s0dn4, div[role="status"], div[aria-live="polite"]'
						);
						for (const x of C) {
							const E =
								((k = x.textContent) == null ? void 0 : k.toLowerCase()) || "";
							if (
								E.includes("invitation") ||
								E.includes("invite") ||
								E.includes("request sent")
							)
								return {
									success: !0,
									method: "invitation-notification",
								};
						}
						return document.querySelector(
							'button[type="submit"], [aria-label*="send"], [data-testid*="send"]'
						)
							? {
									success: !1,
									error: "Message verification failed",
							  }
							: {
									success: !0,
									method: "no-send-button",
							  };
					},
				});
				if ((Y = w == null ? void 0 : w.result) != null && Y.success) {
					oe = !0;
					const P =
						(O = w.result.method) == null ? void 0 : O.includes("invitation");
					i(
						"info",
						"write",
						`${P ? "Invitation" : "Message"} sent to ${t} (verification: ${
							w.result.method || "unknown"
						})`
					);
				} else if (X < 3) {
					const P = Math.min(4e3 * Math.pow(2, X - 1), 45e3);
					i(
						"warning",
						"write",
						`Failed to send message, retrying in ${P}ms (attempt ${X})`
					),
						await W(P);
				}
			} catch (w) {
				if (X < 3) {
					const P = Math.min(6e3 + X * 2500, 2e4);
					i(
						"warning",
						"write",
						`Error sending message: ${w}, retrying in ${P}ms (attempt ${X})`
					),
						await W(P);
				}
			}
		}
		return oe
			? {
					success: !0,
					message: se,
			  }
			: (i("error", "write", `Failed to send message after ${X} attempts`),
			  {
					success: !1,
					message: `Failed to send message after ${X} attempts`,
			  });
	} catch (z) {
		return (
			i("error", "write", `Error for ${t}: ${z}`),
			{
				success: !1,
				message: z,
			}
		);
	} finally {
		s();
	}
}
const ue = {};
async function qe(e, t = 3e4) {
	return (
		ue[e] && clearTimeout(ue[e]),
		await chrome.tabs.update(e, {
			active: !0,
		}),
		(ue[e] = setTimeout(() => {
			delete ue[e];
		}, t)),
		() => {
			ue[e] && (clearTimeout(ue[e]), delete ue[e]);
		}
	);
}
async function Pe(e, t = 3e4) {
	const o = Date.now();
	for (; Date.now() - o < t; ) {
		const [N] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			func: () => {
				const p = document.querySelector(
					'div[role="textbox"][data-testid="dmComposerTextInput"]'
				);
				if (!p) return !1;
				const s = p.getBoundingClientRect(),
					g = window.getComputedStyle(p),
					h =
						g.display !== "none" &&
						g.visibility !== "hidden" &&
						g.opacity !== "0" &&
						s.width > 0 &&
						s.height > 0 &&
						s.top < window.innerHeight &&
						s.bottom > 0 &&
						s.left < window.innerWidth &&
						s.right > 0;
				if (h)
					try {
						p.scrollIntoView({
							behavior: "smooth",
							block: "center",
						}),
							p.focus({
								preventScroll: !1,
							});
					} catch (b) {
						console.warn("Failed to focus message input:", b);
					}
				return h;
			},
		});
		if (N.result === !0) return !0;
		await W(1e3);
	}
	return !1;
}
async function Ne(e, t, o, N, p) {
	var g, h;
	const s = await qe(e, 12e4);
	try {
		const b = await chrome.windows.get((await chrome.tabs.get(e)).windowId);
		for (let y = 0; y < 3; y++)
			try {
				await chrome.tabs.update(e, {
					active: !0,
					url: `https://www.x.com/${t}`,
				});
				break;
			} catch (f) {
				if (
					(g = f.message) != null &&
					g.includes("Tabs cannot be edited right now")
				)
					await W(5e3);
				else throw f;
			}
		await W(ie(1e3, 2e3));
		let K = 0;
		for (; K < 3; ) {
			const y = await chrome.tabs.get(e);
			if (y.active && y.status === "complete") break;
			await W(1e3), K++;
		}
		(await we(e)) ||
			i(
				"warning",
				"write",
				`Failed to add overlay for ${t}, continuing anyway`
			),
			i("info", "write", `Starting DM process for user: ${t}`);
		const V =
			((h = (
				await chrome.scripting.executeScript({
					target: {
						tabId: e,
					},
					func: () => {
						var y;
						try {
							let f;
							const Y = [
								'div[data-testid="UserName"] div[dir="ltr"] span.css-1jxf684[style*="color: rgb(113, 118, 123)"]',
								'div[data-testid="UserName"] div.css-146c3p1[style*="color: rgb(113, 118, 123)"]',
							];
							for (const n of Y) {
								const c = document.querySelectorAll(n);
								for (const S of Array.from(c))
									if (S.textContent && S.textContent.trim().startsWith("@")) {
										f = S.textContent.trim().replace(/^@/, "");
										break;
									}
								if (f) break;
							}
							if (!f) {
								const c = window.location.pathname.match(/^\/([^\/]+)/);
								c && c[1] && (f = c[1]);
							}
							let O;
							const z = document.querySelector(
								'div[data-testid="UserName"] div[dir="ltr"] span.css-1jxf684:not([style*="color: rgb(113, 118, 123)"])'
							);
							if ((z && z.textContent && (O = z.textContent.trim()), !O)) {
								const n = [
									'div[data-testid="UserName"] span.css-1jxf684 > span.css-1jxf684:first-child',
									'div[data-testid="UserName"] div.css-146c3p1[style*="color: rgb(231, 233, 234)"]',
								];
								for (const c of n) {
									const S = document.querySelectorAll(c);
									for (const Z of Array.from(S)) {
										const J = (y = Z.textContent) == null ? void 0 : y.trim();
										if (J && J.length > 1 && !J.includes("@")) {
											O = J;
											break;
										}
									}
									if (O) break;
								}
							}
							let _, a;
							if (O) {
								const n = O.split(" ");
								n.length >= 1 &&
									((_ = n[0]), n.length >= 2 && (a = n.slice(1).join(" ")));
							}
							return {
								firstName: _,
								lastName: a,
								username: f,
								fullName: O,
							};
						} catch (f) {
							return (
								console.error("Error extracting Twitter profile data:", f), {}
							);
						}
					},
					args: [],
				})
			)[0]) == null
				? void 0
				: h.result) || {};
		if (
			(((V != null && V.firstName) || (V != null && V.username)) &&
				i("info", "write", `Found profile data: ${JSON.stringify(V)}`),
			await W(ie(1e3, 2e3)),
			!(await (async (y = 2) => {
				for (let f = 0; f < y; f++)
					try {
						if (
							(await chrome.tabs.update(e, {
								active: !0,
							}),
							(
								await chrome.scripting.executeScript({
									target: {
										tabId: e,
									},
									func: async () =>
										!!document.querySelectorAll(
											'button[data-testid="sendDMFromProfile"]'
										)[0],
								})
							)[0].result === !0)
						)
							return !0;
						await W(3e3);
					} catch (Y) {
						console.error(`Message button check attempt ${f + 1} failed:`, Y);
					}
				return !1;
			})()))
		)
			return (
				i("warning", "write", `Cannot message user ${t}, skipping.`),
				{
					success: !1,
					message: "Cannot message user, DM not available",
				}
			);
		if (
			((o == null ? void 0 : o.followUser) == !0 &&
				(await chrome.scripting.executeScript({
					target: {
						tabId: e,
					},
					func: () => {
						try {
							const f = Array.from(
								document.querySelectorAll(
									'div[data-testid="placementTracking"] button[data-testid$="-follow"]'
								)
							).find((Y) => {
								var O;
								return (O = Y.textContent) == null
									? void 0
									: O.toLowerCase().includes("follow");
							});
							f &&
								(f.scrollIntoView({
									behavior: "smooth",
									block: "center",
								}),
								f.click());
						} catch (y) {
							console.warn("Failed to click follow button", y);
						}
					},
				}),
				await W(ie(1e3, 2e3))),
			await chrome.tabs.update(e, {
				active: !0,
			}),
			!(await (async (y = 3) => {
				for (let f = 0; f < y; f++)
					try {
						if (
							(await chrome.tabs.update(e, {
								active: !0,
							}),
							await W(1e3),
							(
								await chrome.scripting.executeScript({
									target: {
										tabId: e,
									},
									func: async () => {
										var Z, J;

										function O(G) {
											return new Promise((m) => setTimeout(m, G));
										}
										const z = (G) => {
												const m = G.getBoundingClientRect(),
													re = window.getComputedStyle(G);
												return (
													re.display !== "none" &&
													re.visibility !== "hidden" &&
													re.opacity !== "0" &&
													m.width > 0 &&
													m.height > 0 &&
													m.top < window.innerHeight &&
													m.bottom > 0 &&
													m.left < window.innerWidth &&
													m.right > 0
												);
											},
											_ = (G) => {
												try {
													return (
														G.scrollIntoView({
															behavior: "smooth",
															block: "center",
														}),
														new Promise((m) => {
															setTimeout(() => {
																try {
																	G.focus({
																		preventScroll: !0,
																	}),
																		O(500),
																		G.click(),
																		setTimeout(() => {
																			G.dispatchEvent(
																				new MouseEvent("click", {
																					bubbles: !0,
																					cancelable: !0,
																					view: window,
																				})
																			),
																				setTimeout(() => {
																					G.dispatchEvent(
																						new MouseEvent("mousedown", {
																							bubbles: !0,
																							cancelable: !0,
																							view: window,
																						})
																					),
																						G.dispatchEvent(
																							new MouseEvent("mouseup", {
																								bubbles: !0,
																								cancelable: !0,
																								view: window,
																							})
																						),
																						m(!0);
																				}, 200);
																		}, 200);
																} catch (re) {
																	console.error("Click attempt failed:", re),
																		m(!1);
																}
															}, 500);
														})
													);
												} catch (m) {
													return (
														console.error("Click failed:", m),
														Promise.resolve(!1)
													);
												}
											},
											a = document.querySelector(
												'button[data-testid="sendDMFromProfile"]'
											);
										if (a && z(a))
											return (
												console.log(
													"Found direct message button with data-testid"
												),
												await _(a)
											);
										const n = [
											'button[aria-label="Message"]',
											'button[aria-label*="message"]',
											'button[data-testid*="message"]',
											'button[data-testid*="Message"]',
											'button[aria-label="Direct Message"]',
											'button[aria-label="Send Direct Message"]',
											'a[role="button"][href*="messages"]',
										];
										for (const G of n) {
											const m = document.querySelector(G);
											if (m && z(m))
												return (
													console.log(
														`Found message button with selector: ${G}`
													),
													await _(m)
												);
										}
										const c = Array.from(
											document.querySelectorAll('button, [role="button"]')
										);
										for (const G of c) {
											const m = G,
												re =
													((Z = m.textContent) == null
														? void 0
														: Z.toLowerCase()) || "",
												se =
													((J = m.getAttribute("aria-label")) == null
														? void 0
														: J.toLowerCase()) || "";
											if (
												(re.includes("message") || se.includes("message")) &&
												z(m)
											)
												return (
													console.log(
														"Found message button through text content"
													),
													await _(m)
												);
										}
										return (await (async () => {
											const G = [
												'[aria-label="More"]',
												'[aria-label="more"]',
												'[aria-label="More options"]',
												'div[data-testid="caret"]',
												'svg[data-testid="ellipsis"]',
											];
											let m = null;
											for (const oe of G) {
												const X = document.querySelector(oe);
												if (X && z(X)) {
													m = X;
													break;
												}
											}
											if (!m) {
												const oe = document.querySelectorAll("svg path");
												for (const X of Array.from(oe)) {
													const w = X.getAttribute("d") || "";
													if (
														(w.includes(
															"M3 12c0-1.1.9-2 2-2s2 .9 2 2-.9 2-2 2-2-.9-2-2zm9 2c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm7 0c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z"
														) ||
															w.includes(
																"M4.5 10.5c-.825 0-1.5.675-1.5 1.5s.675 1.5 1.5 1.5S6 12.825 6 12s-.675-1.5-1.5-1.5zm15 0c-.825 0-1.5.675-1.5 1.5s.675 1.5 1.5 1.5S21 12.825 21 12s-.675-1.5-1.5-1.5zm-7.5 0c-.825 0-1.5.675-1.5 1.5s.675 1.5 1.5 1.5 1.5-.675 1.5-1.5-.675-1.5-1.5-1.5z"
															)) &&
														((m = X.closest("button")), m && z(m))
													)
														break;
												}
											}
											if (!m) return !1;
											await _(m), await O(1e3);
											const se = Array.from(
												document.querySelectorAll(
													'div[role="menu"] div[role="menuitem"], [role="menuitem"], li[role="presentation"] a, ul li a'
												)
											).find((oe) => {
												var P;
												const X = oe,
													w =
														((P = X.textContent) == null
															? void 0
															: P.toLowerCase()) || "";
												return (
													(w.includes("message") || w.includes("dm")) && z(X)
												);
											});
											return se ? await _(se) : !1;
										})())
											? (console.log(
													"Found message button through options menu"
											  ),
											  !0)
											: (console.log(
													"Failed to find message button with any strategy"
											  ),
											  !1);
									},
								})
							)[0].result == !0)
						)
							return !0;
						await W(7e3);
					} catch (Y) {
						console.error(`Attempt ${f + 1} failed:`, Y);
					}
				return !1;
			})()))
		)
			throw new Error("Failed to find message button after multiple attempts");
		if (!(await Pe(e, 3e4)))
			return (
				i("error", "write", `Failed to open messages window: ${t}`),
				{
					success: !1,
					message: `Failed to open messages window: ${t}`,
				}
			);
		await W(ie(1500, 2500));
		let I = p ? N : pe(o, V);
		(I = I.replace(
			/\r\n/g,
			`
`
		).replace(
			/\r/g,
			`
`
		)),
			I.includes(`
`) &&
				(i(
					"info",
					"write",
					`Preparing multi-paragraph message with ${
						I.split(`
`).length
					} paragraphs`
				),
				I.split(
					`
`
				).forEach((y, f) => {
					y.trim().length > 0 &&
						i(
							"info",
							"write",
							`Paragraph ${f + 1}: ${y.substring(0, 30)}${
								y.length > 30 ? "..." : ""
							}`
						);
				})),
			await chrome.tabs.update(e, {
				active: !0,
			});
		const [$] = await chrome.scripting.executeScript({
			target: {
				tabId: e,
			},
			args: [I],
			func: (y) => {
				const f = document.querySelector(
						"[data-testid='dmComposerTextInput'].public-DraftEditor-content"
					),
					Y = document.querySelector("[data-testid='dmComposerSendButton']");
				if (!f || !Y)
					return console.error("Editable or send button not found."), !1;
				const O = (_) => {
					const a = document.createRange(),
						n = getSelection();
					a.selectNodeContents(_),
						a.collapse(!1),
						n.removeAllRanges(),
						n.addRange(a);
				};
				return (
					((_, a) => {
						_.focus(), O(_);
						try {
							const n = new DataTransfer();
							n.setData("text/plain", a);
							const c = new ClipboardEvent("paste", {
								bubbles: !0,
								clipboardData: n,
							});
							_.dispatchEvent(c);
						} catch {}
						_.dispatchEvent(
							new InputEvent("beforeinput", {
								bubbles: !0,
								inputType: "insertFromPaste",
								data: a,
							})
						),
							_.dispatchEvent(
								new InputEvent("input", {
									bubbles: !0,
									inputType: "insertFromPaste",
									data: a,
								})
							);
					})(f, y),
					setTimeout(() => {
						Y.getAttribute("aria-disabled") === "true"
							? (f.dispatchEvent(
									new KeyboardEvent("keydown", {
										key: "Enter",
										code: "Enter",
										bubbles: !0,
									})
							  ),
							  f.dispatchEvent(
									new KeyboardEvent("keyup", {
										key: "Enter",
										code: "Enter",
										bubbles: !0,
									})
							  ),
							  console.log("Sent via Enter."))
							: (Y.click(), console.log("Clicked Send."));
					}, 150),
					!0
				);
			},
		});
		return $ != null && $.result
			? (i("info", "write", `Dispatched DM send to ${t}`),
			  {
					success: !0,
					message: I,
			  })
			: {
					success: !1,
					message: "Failed to dispatch send sequence",
			  };
	} catch (b) {
		return (
			i("error", "write", `Error for ${t}: ${b}`),
			{
				success: !1,
				message: b,
			}
		);
	} finally {
		s();
	}
}
const Ue = async (e, t, o, N, p, s) => {
	const g = (t == null ? void 0 : t.username) ?? "";
	if (!g)
		return {
			success: !1,
			message: "Username is missing.",
		};
	if (s === "instagram") return Te(e, g, o, N, p);
	if (s === "twitter") return Ne(e, g, o, N, p);
};
export { Se as A, Fe as D, Ve as c, Be as g, i as l, Ue as w };
