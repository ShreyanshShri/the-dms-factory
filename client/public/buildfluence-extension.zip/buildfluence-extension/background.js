var x = Object.defineProperty;
var _ = (e, r, s) =>
	r in e
		? x(e, r, {
				enumerable: !0,
				configurable: !0,
				writable: !0,
				value: s,
		  })
		: (e[r] = s);
var T = (e, r, s) => _(e, typeof r != "symbol" ? r + "" : r, s);
import { l as t, A as w, D as j, w as R } from "./assets/workflow-DPkTZJd0.js";
import "./assets/vendor-BJT0b45B.js";
const p = "buildfluence_persistentLeads",
	N = 2,
	O = 5 * 60 * 1e3;
async function B(e, r, s, a, i, n, c) {
	try {
		const u = {
				lead: e,
				campaignData: r,
				campaignId: s,
				accountId: a,
				followUpText: i,
				followUp: n,
				type: c,
				timestamp: Date.now(),
				retryCount: 0,
			},
			o = ((await chrome.storage.local.get([p]))[p] || []).filter(
				(g) => g.lead._id !== e._id
			);
		o.push(u),
			await chrome.storage.local.set({
				[p]: o,
			}),
			t(
				"info",
				"persistence",
				`Saved lead ${e.username} to persistent storage`
			);
	} catch (u) {
		t(
			"error",
			"persistence",
			`Failed to save lead ${e.username} to storage: ${u}`
		);
	}
}
async function U(e) {
	try {
		const a = ((await chrome.storage.local.get([p]))[p] || []).filter(
			(i) => i.lead._id !== e
		);
		await chrome.storage.local.set({
			[p]: a,
		}),
			t("info", "persistence", `Removed lead ${e} from persistent storage`);
	} catch (r) {
		t("error", "persistence", `Failed to remove lead ${e} from storage: ${r}`);
	}
}
async function M() {
	try {
		const r = (await chrome.storage.local.get([p]))[p] || [];
		if (r.length === 0) return;
		t("info", "persistence", `Found ${r.length} persisted leads to retry`);
		const s = Date.now(),
			a = [],
			i = [];
		for (const n of r) {
			if (n.retryCount >= N || s - n.timestamp > O) {
				t(
					"warning",
					"persistence",
					`Lead ${n.lead.username} exceeded retry limits, removing`
				),
					i.push(n.lead._id);
				continue;
			}
			const c = Math.min(2e3 * Math.pow(2, n.retryCount), 3e5);
			s - n.timestamp >= c && (n.retryCount++, (n.timestamp = s), a.push(n));
		}
		if (i.length > 0) {
			const n = r.filter((c) => !i.includes(c.lead._id));
			await chrome.storage.local.set({
				[p]: n,
			});
		}
		for (const n of a)
			t(
				"info",
				"persistence",
				`Retrying persisted lead ${n.lead.username} (attempt ${n.retryCount})`
			),
				await $(Math.floor(Math.random() * 5e3) + 1e3),
				await v(
					n.lead,
					n.campaignData,
					n.campaignId,
					n.accountId,
					n.followUpText,
					n.followUp,
					n.type,
					!0
				);
	} catch (e) {
		t("error", "persistence", `Error during persisted leads retry: ${e}`);
	}
}

function $(e) {
	return new Promise((r) => setTimeout(r, e));
}

function G(e, r) {
	return Math.floor(Math.random() * (r - e + 1)) + e;
}
async function L(e, r, s, a, i, n, c) {
	try {
		await fetch(`${w}/analytics`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			credentials: "include",
			body: JSON.stringify({
				campaignID: e,
				accountID: r,
				leadID: s,
				username: a,
				message: i,
				status: n,
				platform: c,
			}),
		});
	} catch (u) {
		t("error", "sendAnalytics", `Failed to send analytics: ${u}`);
	}
}
let l = null;
const b = "buildfluence_persistentTabId";
let y = !1;
const h = async () => {
		try {
			if (l !== null)
				try {
					await chrome.tabs.get(l);
					return;
				} catch {
					l = null;
				}
			if (l === null) {
				const a = (await chrome.storage.local.get([b]))[b];
				if (typeof a == "number")
					try {
						await chrome.tabs.get(a), (l = a);
						return;
					} catch {
						await chrome.storage.local.remove(b);
					}
			}
			const e = await new Promise((s) =>
				chrome.tabs.query(
					{
						url: "https://dm-factory-background.vercel.app/*",
					},
					(a) => s(a)
				)
			);
			if (e.length > 0 && e[0].id) {
				l = e[0].id;
				const s = e.slice(1).filter((a) => a.id !== void 0);
				for (const a of s)
					try {
						await new Promise((i) => chrome.tabs.remove(a.id, i));
					} catch {}
				try {
					await chrome.tabs.update(l, {
						pinned: !0,
						active: !0,
					});
				} catch (a) {
					t(
						"error",
						"ensurePersistentTab",
						`Error pinning existing runner tab: ${a}`
					);
				}
				await chrome.storage.local.set({
					[b]: l,
				});
				return;
			}
			const r = await new Promise((s, a) =>
				chrome.tabs.create(
					{
						pinned: !0,
						active: !0,
						url: "https://dm-factory-background.vercel.app/",
					},
					(i) => {
						chrome.runtime.lastError
							? a(new Error(chrome.runtime.lastError.message))
							: s(i);
					}
				)
			);
			r.id &&
				((l = r.id),
				await chrome.storage.local.set({
					[b]: l,
				}),
				t("info", "ensurePersistentTab", "Created new persistent tab"));
		} catch (e) {
			t(
				"error",
				"ensurePersistentTab",
				`Failed to ensure persistent tab: ${e}`
			);
		}
	},
	K = (e) => {
		const i = (e.messageLimits || {}).max;
		if (i && i > 0) {
			const n = Math.max(Math.floor(36e5 / i), 3e4),
				c = Math.floor(n * (0.3 + Math.random() * 0.4));
			return n + c;
		}
		return G(3e4, 9e4);
	},
	W = async (e, r) => {
		try {
			const s = await fetch(`${w}/check-response`, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
					},
					credentials: "include",
					body: JSON.stringify({
						camapignID: e,
						username: r.username,
					}),
				}),
				a = await s.json();
			console.log("checkResponse", a);
			return s.ok && a.status ? a.status || "noResponse" : "found";
		} catch (s) {
			return (
				t(
					"error",
					"checkCampaignUpdates",
					`Error checking response for campaign: ${s}`
				),
				"found"
			);
		}
	},
	D = async (e, r) => {
		try {
			await $(5e3);
			const s = await fetch(`${w}/fetch-lead?campaignID=${e}&leadID=${r}`, {
				method: "GET",
				headers: {
					"Content-Type": "application/json",
				},
				credentials: "include",
			});
			const x = await s.json();
			console.log("fetchLead", x);
			return s.ok
				? x.lead
				: (t(
						"error",
						"fetchLatestLead",
						`Failed to fetch latest lead ${r} for campaign: ${s.statusText}`
				  ),
				  null);
		} catch (s) {
			return (
				t(
					"error",
					"fetchLatestLead",
					`Error fetching latest lead ${r} for campaign: ${s}`
				),
				null
			);
		}
	},
	H = async (e, r) => {
		try {
			await $(5e3);
			const s = await fetch(
				`${w}/set-lead-status?campaignID=${e}&leadID=${r}`,
				{
					method: "PUT",
					headers: {
						"Content-Type": "application/json",
					},
					credentials: "include",
				}
			);
			const x = await s.json();
			console.log("setLeadStatus", x);
			return s.ok
				? x.success
				: (t(
						"error",
						"fetchLatestLead",
						"Failed to set latest lead status for campaign"
				  ),
				  null);
		} catch (s) {
			return (
				t(
					"error",
					"fetchLatestLead",
					`Error fetching latest lead ${r} for campaign: ${s}`
				),
				null
			);
		}
	};
async function v(e, r, s, a, i, n, c, u = !1) {
	const d = c === "instagram" ? "https://www.instagram.com/" : "https://x.com/";
	try {
		if (
			(u || (await B(e, r, s, a, i, n, c)),
			l === null && (await h(), l === null))
		)
			throw new Error("Failed to create persistent tab");
		try {
			const o = await chrome.tabs.get(l);
			if (
				(!o || o._id !== l) &&
				(t(
					"warning",
					"processSingleLead",
					`Tab invalid, recreating before processing ${e.username}`
				),
				await h(),
				l === null)
			)
				throw new Error("Failed to create a new persistent tab");
			(!o.url || !o.url.includes(d)) &&
				(await chrome.tabs.update(l, {
					url: d,
				}),
				await $(3e3));
		} catch (o) {
			if (
				(t(
					"error",
					"processSingleLead",
					`Error verifying tab for ${e.username}: ${o}`
				),
				(l = null),
				await h(),
				l === null)
			)
				throw new Error("Failed to recreate persistent tab");
		}
		t(
			"info",
			"processSingleLead",
			`Starting to DM ${e.username}${u ? " (retry)" : ""}`
		);
		const f = await R(l, e, r, i, n, c);
		if (
			(t(
				"info",
				"processSingleLead",
				`${e.username}: ${f.success ? "Success" : "Unable to DM this lead"}`
			),
			f.success)
		) {
			const o = n ? "followup" : "initialdmsent";
			console.log("analytics", r);
			await L(
				(r == null ? void 0 : r.id) ?? "",
				a,
				(e == null ? void 0 : e._id) ?? "",
				(e == null ? void 0 : e.username) ?? "",
				f.message,
				o,
				c
			),
				await U(e._id),
				t(
					"info",
					"processSingleLead",
					`Successfully processed ${e.username} (${o})`
				);
		} else
			await L(
				(r == null ? void 0 : r.id) ?? "",
				a,
				(e == null ? void 0 : e._id) ?? "",
				(e == null ? void 0 : e.username) ?? "",
				"",
				"failed",
				c
			),
				u && (await U(e._id)),
				t(
					"error",
					"processSingleLead",
					`Failed to process ${e.username}: ${f.message || "Unknown error"}`
				);
	} catch (f) {
		t(
			"error",
			"processSingleLead",
			`Unhandled error processing ${
				(e == null ? void 0 : e.username) || "unknown lead"
			}: ${f}`
		);
		try {
			await L(
				(r == null ? void 0 : r.id) ?? "",
				a,
				(e == null ? void 0 : e._id) ?? "",
				(e == null ? void 0 : e.username) ?? "",
				"",
				String(f),
				c
			);
		} catch (o) {
			t(
				"error",
				"processSingleLead",
				`Error sending error analytics for ${
					(e == null ? void 0 : e.username) || "unknown lead"
				}: ${o}`
			);
		}
		u && (await U(e._id));
	}
}
const Y = async (e, r, s, a, i) => {
		var d;
		const n = e.platform || "instagram",
			c = n === "instagram" ? "https://www.instagram.com/" : "https://x.com/";
		if (!a || a.length === 0) {
			t("info", "processUsers", "No DMs to be sent at this time");
			return;
		}
		if (l === null) await h();
		else
			try {
				await chrome.tabs.get(l);
			} catch {
				(l = null), await h();
			}
		if (l === null) {
			t(
				"error",
				"processUsers",
				"Failed to create persistent tab, cannot process leads"
			);
			return;
		}
		const u = Math.floor(Math.random() * 3e4) + 5e3;
		if (
			(t("info", "processUsers", `Adding delay of ${u}ms before sending DMs`),
			await $(u),
			y)
		) {
			t(
				"info",
				"processLeads",
				"Skipped execution as processing is already in progress."
			);
			return;
		}
		y = !0;
		try {
			for (let f = 0; f < a.length; f++) {
				const o = a.shift();
				if (!o) {
					t("warning", "processUsers", "Encountered empty lead, skipping");
					continue;
				}
				try {
					if (l == null) continue;
					t("info", "processUsers", `Processing lead ${o.username}`);
					let g;
					try {
						g = await D(r, o._id);
					} catch (m) {
						t(
							"error",
							"processUsers",
							`Error fetching latest lead data for ${o.username}: ${m}`
						);
						continue;
					}
					if (!g) {
						t(
							"error",
							"processUsers",
							`Failed to fetch latest lead data for ${o.username}`
						);
						continue;
					}
					if (String(g.assignedAccount) !== String(s)) {
						t(
							"info",
							"processUsers",
							`Lead ${o.username} no longer assigned to this account`
						);
						continue;
					}
					if ((g.status || "").trim().toLowerCase() === "sending") {
						t(
							"info",
							"processUsers",
							`Lead ${o.username} is already being processed`
						);
						continue;
					}
					let E = !1;
					try {
						(E = await H(r, o._id)),
							t(
								"info",
								"processUsers",
								`Updated status for ${o.username} to 'sending'`
							);
					} catch (m) {
						t(
							"info",
							"processUsers",
							`Error updating status for ${o.username}: ${m}`
						);
						continue;
					}
					if (!E) {
						t(
							"info",
							"processUsers",
							`Failed to update status for ${o.username}`
						);
						continue;
					}
					let S = !1,
						k = "";
					if (o.type === "followUp")
						try {
							const m = await W(r, o);
							if (
								(t(
									"info",
									"processUsers",
									`Checked response status for ${o.username}: ${m}`
								),
								m === "found")
							) {
								t(
									"info",
									"processUsers",
									`Skipping follow-up for ${o.username}, already responded`
								);
								continue;
							}
							(k =
								((d = o == null ? void 0 : o.followUps[0]) == null
									? void 0
									: d.message) ?? ""),
								(S = !0);
						} catch (m) {
							t(
								"error",
								"processUsers",
								`Error checking response status for ${o.username}: ${m}`
							);
							continue;
						}
					try {
						await chrome.tabs.update(l, {
							url: c,
							active: !0,
						});
					} catch (m) {
						t(
							"error",
							"processUsers",
							`Error updating tab for ${o.username}: ${m}`
						);
						continue;
					}
					let P;
					try {
						(P = await new Promise((m, I) => {
							chrome.windows.getCurrent((F) => {
								chrome.runtime.lastError
									? I(new Error(chrome.runtime.lastError.message))
									: m(F);
							});
						})),
							t("info", "processUsers", `Got current window for ${o.username}`);
					} catch (m) {
						t(
							"error",
							"processUsers",
							`Error getting current window for ${o.username}: ${m}`
						);
						continue;
					}
					try {
						await v(o, e, r, s, k, S, n, !1);
					} catch (m) {
						t(
							"error",
							"processUsers",
							`Error during processSingleLead for ${o.username}: ${m}`
						);
						continue;
					}
					const C = K(e);
					t(
						"info",
						"processUsers",
						`Adding pacing delay of ${C}ms before next lead`
					),
						await $(C);
				} catch (g) {
					t(
						"error",
						"processUsers",
						`Unhandled error processing ${
							(o == null ? void 0 : o.username) || "unknown lead"
						}: ${g}`
					);
					try {
						await L(
							(e == null ? void 0 : e.id) ?? "",
							s,
							(o == null ? void 0 : o._id) ?? "",
							(o == null ? void 0 : o.username) ?? "",
							"",
							String(g),
							n
						);
					} catch (E) {
						t(
							"error",
							"processUsers",
							`Error sending error analytics for ${
								(o == null ? void 0 : o.username) || "unknown lead"
							}: ${E}`
						);
					}
				}
			}
			try {
				t("info", "processUsers", "Resetting tab to default"),
					await chrome.tabs.update(l, {
						url: "https://dm-factory-background.vercel.app/",
					});
			} catch (f) {
				t(
					"error",
					"processUsers",
					`Error resetting tab to default state: ${f}`
				);
			}
		} finally {
			y = !1;
		}
	},
	A = async (e, r) => {
		var c;
		const s = await fetch(`${w}/account-status?widgetID=${e}`, {
				method: "GET",
				headers: {
					"Content-Type": "application/json",
				},
				credentials: "include",
			}),
			a = await s.json();
		console.log("Account status:", a);
		let i = !0;
		s.ok && a.success
			? a.account.status === "active"
				? (i = !0)
				: (i = !1)
			: t("error", "checkAccount", "Can't check account status for campaign");
		const n = (c = a.account) == null ? void 0 : c.campaignId;
		if (i)
			try {
				const u = await fetch(`${w}/campaign-status?campaignID=${n}`, {
						method: "GET",
						headers: {
							"Content-Type": "application/json",
						},
						credentials: "include",
					}),
					d = await u.json();
				console.log("Campaign status:", d);
				u.ok && d.success
					? d.campaign.withinWorkingHours == !0
						? (t(
								"info",
								"checkCampaignUpdates",
								"Check Successful (within working hours)"
						  ),
						  await J(d.campaign, n, r))
						: t(
								"info",
								"checkCampaignUpdates",
								"Check Successful (outside working hours)"
						  )
					: t(
							"error",
							"checkCampaignUpdates",
							`Failed to fetch updates for campaign ${n}: ${d.message}`
					  );
			} catch (u) {
				t(
					"error",
					"checkCampaignUpdates",
					`Error checking updates for campaign: ${u}`
				);
			}
		else {
			t("info", "checkCampaignUpdates", "Account not active");
			return;
		}
	},
	J = async (e, r, s) => {
		try {
			await h();
			const a = e.platform || "instagram",
				i = `${a}WidgetId`,
				n = await new Promise((d) => {
					chrome.storage.local.get([i], (f) => d(f[i] ?? null));
				});
			if (!n) {
				t(
					"error",
					"fetchAssignedLeads",
					`No ${a} widget ID found for campaign.`
				);
				return;
			}
			console.log(`${w}/fetch-leads?campaignID=${r}&accountId=${n}`);
			const c = await fetch(`${w}/fetch-leads?campaignID=${r}&accountId=${n}`, {
					method: "GET",
					headers: {
						"Content-Type": "application/json",
					},
					credentials: "include",
				}),
				u = await c.json();
			console.log("Fetch Leads", u);
			c.ok && u.success
				? (t("info", "fetchAssignedLeads", "Processing leads"),
				  await Y(e, e._id, n, u.leads, s))
				: t(
						"error",
						"fetchAssignedLeads",
						`Failed to get leads for campaign: ${u.message}`
				  );
		} catch (a) {
			t(
				"error",
				"fetchAssignedLeads",
				`Error fetching leads for campaign: ${a}`
			);
		}
	},
	q = async (e, r = "instagram") => {
		const a = `checkCampaignUpdates-${encodeURIComponent(e)}-${r}`;
		await new Promise((i) => chrome.alarms.clear(a, i)),
			chrome.alarms.create(a, {
				periodInMinutes: 10,
			});
	};
chrome.alarms.onAlarm.addListener(async (e) => {
	if (!e.name.includes("-")) return;
	const r = e.name.split("-"),
		s = r[0],
		a = r.length > 1 ? decodeURIComponent(r[1]) : "",
		i = r.length > 2 ? r[2] : "instagram";
	if (l === null) await h();
	else
		try {
			await chrome.tabs.get(l);
		} catch {
			t("info", "alarmListener", "Tab is no longer valid, creating a new one"),
				(l = null),
				await h();
		}
	const n = Math.floor(Math.random() * 6e4);
	if (
		(await $(n),
		s === "checkCampaignUpdates" &&
			(t("info", "periodicCheck", `Running periodic check for ${i} account`),
			await M(),
			a))
	) {
		const c = Math.floor(Math.random() * 2) + 5;
		A(a, c);
	}
});
chrome.runtime.onSuspend.addListener(async () => {
	t(
		"info",
		"gracefulClosure",
		"Extension is about to be suspended, performing cleanup"
	);
	try {
		const r = (await chrome.storage.local.get([p]))[p] || [];
		for (const s of r)
			try {
				await fetch(`${w}/update-lead-status`, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
					},
					body: JSON.stringify({
						campaignId: s.campaignId,
						leadId: s.lead._id,
						status: "pending_retry",
					}),
				}),
					console.log("Updated lead status", s.lead.username, "pending_retry");
				t(
					"info",
					"gracefulClosure",
					`Marked lead ${s.lead.username} as pending_retry`
				);
			} catch (a) {
				t(
					"warning",
					"gracefulClosure",
					`Failed to update status for ${s.lead.username}: ${a}`
				);
			}
		(y = !1), t("info", "gracefulClosure", "Cleanup completed");
	} catch (e) {
		t("error", "gracefulClosure", `Error during cleanup: ${e}`);
	}
});
chrome.runtime.onMessage.addListener((e, r, s) => {
	if (e.type === "fetchAudio")
		return (
			(async () => {
				try {
					const a = await fetch(e.url);
					console.log("Fetching audio from URL:", a.url);
					if (!a.ok) throw new Error(`HTTP ${a.status}`);
					const i = await a.arrayBuffer(),
						n = btoa(String.fromCharCode(...new Uint8Array(i))),
						u = `data:${
							a.headers.get("content-type") || "audio/mpeg"
						};base64,${n}`;
					s({
						success: !0,
						dataUrl: u,
					});
				} catch (a) {
					s({
						success: !1,
						error: a.message,
					});
				}
			})(),
			!0
		);
});
chrome.runtime.onMessage.addListener((e, r, s) => {
	console.log("Background script received message:", e);
	const { action: a, widgetId: i, platform: n } = e;
	return a === j && i
		? (console.log(`Starting campaign: Widget ID=${i}, Platform=${n}`),
		  (async () => {
				try {
					const c = n || "instagram";
					if (
						(t(
							"info",
							"startCampaign",
							`Starting ${c} campaign in 1 minute, then checking every 10 minutes`
						),
						await h(),
						l === null)
					)
						throw new Error("Failed to create persistent tab for campaign");
					await q(i, c),
						setTimeout(() => {
							const u = Math.floor(Math.random() * 2) + 5;
							A(i, u);
						}, 6e4),
						s({
							success: !0,
							message: "Campaign successfully started",
						});
				} catch (c) {
					t("error", "startCampaign", `Error starting campaign: ${c}`),
						s({
							success: !1,
							error: String(c),
						});
				}
		  })(),
		  !0)
		: e.action === "REFRESH_BACKGROUND"
		? ((async () => {
				try {
					chrome.alarms.clearAll();
					const u = (
						await new Promise((d) =>
							chrome.tabs.query(
								{
									pinned: !0,
								},
								(f) => d(f)
							)
						)
					).filter(
						(d) => d.url === "https://dm-factory-background.vercel.app/"
					);
					for (const d of u)
						d._id !== void 0 &&
							(await new Promise((f) => chrome.tabs.remove(d._id, f)));
					chrome.runtime.reload();
				} catch (c) {
					console.error("Failed to refresh background:", c),
						s({
							success: !1,
							error: String(c),
						});
				}
		  })(),
		  !0)
		: (s({
				status: "alive",
		  }),
		  !0);
});
class V {
	constructor(r) {
		T(this, "timer", null);
		T(this, "intervalMs", 2e4);
		r && (this.intervalMs = r);
	}
	start() {
		this.stop(),
			(this.timer = setInterval(() => {
				this.ping();
			}, this.intervalMs)),
			this.ping();
	}
	stop() {
		this.timer && (clearInterval(this.timer), (this.timer = null));
	}
	async ping() {
		try {
			if ((await chrome.runtime.getPlatformInfo(), l !== null))
				try {
					await chrome.tabs.get(l),
						Math.random() < 0.1 &&
							!y &&
							(await chrome.tabs.update(l, {
								url: "https://dm-factory-background.vercel.app/",
							}));
				} catch {
					(l = null), y || (await h());
				}
			else y || (await h());
		} catch (r) {
			t("error", "keepAlive", `Keep-alive ping failed: ${r}`);
		}
	}
}
const X = new V();
X.start();
t(
	"info",
	"startup",
	"Extension background script loaded, checking for persisted leads"
);
M().catch((e) => {
	t("error", "startup", `Error during startup persistence check: ${e}`);
});
